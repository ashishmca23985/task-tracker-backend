const generateDateTime = async() => {
    try{
    const now = new Date();

    const date = now.toISOString().split('T')[0]; // YYYY-MM-DD
    const time = now.toTimeString().split(' ')[0]; // HH:MM:SS
  
    return `${date} ${time}`;
    }
    catch(err){
        return err;
    }
};



const SaveCurrentDateAndTime = async() => {
    const now = new Date();
  
    // Extract current time parts
    const hours = String(now.getUTCHours()).padStart(2, '0');
    const minutes = String(now.getUTCMinutes()).padStart(2, '0');
    const seconds = String(now.getUTCSeconds()).padStart(2, '0');
    const milliseconds = String(now.getUTCMilliseconds()).padStart(3, '0');
  
    // Combine with given date
    return `${dateString}T${hours}:${minutes}:${seconds}.${milliseconds}+00:00`;
  };

module.exports = {
    generateDateTime,SaveCurrentDateAndTime
};
