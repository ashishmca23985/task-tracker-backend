const path = require("path");

const getLocalFilePath = (fileurl) => {
  const cleanPath = fileurl.replace(/^\/+/, "");
  return path.join(__dirname, "../", cleanPath);
};

module.exports = { getLocalFilePath };
