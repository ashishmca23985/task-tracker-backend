// utils/status.js

const STATUS_CODE = {
  NOT_FOUND: 404,
  UNAUTHORIZE: 401,
  SUCCESS: 200,
  INVALID_TOKEN: 401,
  SERVER_ERROR: 500,
};
const status = {
  SUCCESS: (message = "Success", data = null) => ({
    status: "SUCCESS",
    statusCode: 200,
    message,
    data,
  }),
  ERROR: (message = "Error") => ({
    status: "ERROR",
    statusCode: 400,
    message,
  }),
  SERVER_ERROR: (message = "Internal Server Error",error='Server Error') => ({
    status: "SERVER_ERROR",
    statusCode: 500,
    message,
    error
  }),
  NOT_FOUND: (message = "Invalid Credentials") => ({
    status: "NOT_FOUND",
    statusCode: 404,
    message,
  }),
  USER_ALREADY_EXISTS: (message = "User already exists") => ({
    status: "ALREADY_EXISTS",
    statusCode: 409,
    message,
  }),
  BAD_REQUEST: (message = "field is required.") => ({
    status: "BAD_REQUEST",
    statusCode: 400,
    message,
  }),
};

module.exports = { status, STATUS_CODE };
