const JWT=require('jsonwebtoken');
const dotenv=require('dotenv');
dotenv.config();
const secretKey=process.env.SECRET;
const BearerToken=async(userData)=>{
    try{
   const Token=JWT.sign(userData,secretKey,{ expiresIn: '1h' });
   return Token;
    }
    catch(err) {return err};
}

module.exports={
    BearerToken
}