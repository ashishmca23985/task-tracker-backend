
 
 const getTodayDateFormatted = async() => {
    const today = new Date();
    const year = today.getFullYear();
    const month = `${today.getMonth() + 1}`.padStart(2, '0');
    const day = `${today.getDate()}`.padStart(2, '0');
    return `${year}${month}${day}`;
  };

 const TaskId=async(oldTaskid)=>{
    const datenow=await getTodayDateFormatted();
    return `TSK-#${datenow}000${oldTaskid+1}`
};

const NotesId=async(oldTaskid)=>{
  const datenow=await getTodayDateFormatted();
  return `Note-#${datenow}000${oldTaskid+1}`
};

const stringToDate = async (stringDate) => {
    console.log("string data---------",stringDate);
    const dateObj = new Date(stringDate);
  
    if (isNaN(dateObj.getTime())) {
      throw new Error('Invalid date format');
    }
  
    console.log("--------------",dateObj);
    return dateObj;
  };

module.exports={TaskId,stringToDate,NotesId}