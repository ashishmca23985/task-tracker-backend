const { UserModel } = require("../../model/User/userModel");
const teamRepositiories = require("../../repositories/mongoRepositories/teamRepositiories");
const { status, STATUS_CODE } = require("../../utils/statusSender");
class TeamController {
  static CreateTeam = async (req, res) => {
    try {
      const { name, createdBy} = req.body;
      console.log("controller fdata---------", req.body);
      if(!name || !createdBy) {
        console.log("Name or UserId is missing");
      }
      const createTeam = await teamRepositiories.CreateTeam({
        name: name,
        createdBy: createdBy,
      });

      return res.status(200).json(status.SUCCESS("Team created", createTeam));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static getTeam = async (req, res) => {
    try {
      const getDesignation = await teamRepositiories.getTeam();

      return res
        .status(200)
        .json(status.SUCCESS("User created", getDesignation));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static getTeamWiseMember = async (req, res) => {
    try {
      const { id } = req.query;
      const getDesignation = await teamRepositiories.getTeamWiseMember(id);

      return res
        .status(200)
        .json(status.SUCCESS("User created", getDesignation));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static deleteTeam = async (req, res) => {
    try {
      const { id } = req.query;
      const getDesignation = await teamRepositiories.deleteTeam(id);

      return res
        .status(200)
        .json(status.SUCCESS("User created", getDesignation));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static CreateDegignation = async (req, res) => {
    try {
      const { name , createdBy } = req.body;
      const createTeam = await teamRepositiories.CreateDesignation({
        name: name,
        createdBy: createdBy,
      });

      return res.status(200).json(status.SUCCESS("User created", createTeam));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static getDegignation = async (req, res) => {
    try {
      const getDesignation = await teamRepositiories.getDesignation();

      return res
        .status(200)
        .json(status.SUCCESS("User created", getDesignation));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static AddTeamMember = async (req, res) => {
    try {
      const userData = req.body;
      console.log("controller fdata---------", userData);
      // const getDesignation = await teamRepositiories.addTeamMember(userData);
      const updatedUser = await UserModel.findByIdAndUpdate(
        userData.userid,
        { $set: { department: userData.departmentid } }, // Assuming you want to set the department
        { new: true }
      );

      if(!updatedUser) {
        return res.status(404).json(
          status.NOT_FOUND("User not found or update failed")
        );
      } else {
        console.log("User updated successfully:", updatedUser);
      }

      return res
        .status(200)
        .json(status.SUCCESS("User created", updatedUser));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static GetTeamMember = async (req, res) => {
    try {
      const getDesignation = await teamRepositiories.getTeamMember();

      return res
        .status(200)
        .json(status.SUCCESS("User created", getDesignation));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static GetTeamByDepartmentId = async (req, res) => {
    try {
      const { deptId } = req.query;
      const getDesignation = await teamRepositiories.getTeamWiseUserById(
        deptId
      );

      return res
        .status(200)
        .json(status.SUCCESS("User created", getDesignation));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

static removeUserFromTeam = async (req, res) => {
  try {
    const { userId } = req.body;

    if (!userId) {
      return res.status(400).json({
        success: false,
        message: "User ID not provided",
      });
    }

    // Update the user: unset or clear department
    const updatedUser = await UserModel.findByIdAndUpdate(
      userId,
       { department: "" }, // or use { department: "" } to just blank it
      { new: true }
    );

    if (!updatedUser) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "User removed from team successfully",
      data: updatedUser,
    });

  } catch (error) {
    console.error("Error in removeUserFromTeam:", error);
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
}; // working correctly

}
module.exports = TeamController;
