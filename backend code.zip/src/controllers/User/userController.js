const { TaskStatusModal } = require("../../model/User/taskModel");
const taskRepositiories = require("../../repositories/mongoRepositories/taskRepositiories");
const teamRepositiories = require("../../repositories/mongoRepositories/teamRepositiories");
const UserRepositoryMongo = require("../../repositories/mongoRepositories/userRepositiries");
const { TaskId, stringToDate, NotesId } = require("../../utils/service");
const { status } = require("../../utils/statusSender");
const { hashPassword } = require("../../services/encryptionService");
const { UserModel } = require("../../model/User/userModel");
const { TaskModal } = require("../../model/User/taskModel");
const { RoleModel } = require("../../model/User/userModel");
const { TaskLogsModal } = require("../../model/User/taskModel");
const { TaskAttachmentModal } = require("../../model/User/taskModel");
const { DepartmentModel } = require("../../model/User/userModel");
const { NotificationModal } = require("../../model/User/taskModel");
const { TeamModel } = require("../../model/User/teamModal");
const path = require("path");
const fs = require("fs");
const { getLocalFilePath } = require("../../utils/filepath");
const mongoose = require("mongoose");

class UserController {
  static AssigntoUserupdate = async (req, res) => {
    try {
      console.log("API hit");

      const { userthatassigned, usertowhichassigned } = req.body;

      const userUpdate = await UserModel.findByIdAndUpdate(
        usertowhichassigned,
        { $set: { assignedTo: userthatassigned } }, // Overwrites the previous value
        { new: true }
      );

      if (!userUpdate) {
        res.status(404).send({
          message: "User not found",
        });
      }

      console.log("User updated:", userUpdate);

      res.status(200).send(status.SUCCESS("User updated", userUpdate));
    } catch (err) {
      console.error(err);
      res.status(500).send({
        message: "Server error",
        error: err,
      });
    }
  };

  static getUser = async (req, res) => {
    try {
      console.log("api hits");
      const search = req.query?.search || null;
      console.log("Search query:", search);
      const { userId, userType } = req.query;
      console.log("userId and userType:", userId, userType);

      const User = await UserRepositoryMongo.getAllUsers({
        search,
        userId,
        userRole: userType,
      });
      // console.log("user data----------", User);
      res.status(200).send(status.SUCCESS("User fetched", User));
    } catch (err) {
      res.status(500).send({
        messege: "Server error",
        error: err,
      });
    }
  };

  static AddUser = async (req, res) => {
    try {
      console.log("api hits");
      const { name, ...UserData } = req.body;
      console.log("userdata----------", name);
      console.log("userdata----------", UserData);
      const isUser = await UserRepositoryMongo.findeUserByEmail(UserData.email);
      console.log("find userby email----------", isUser);
      if (isUser) {
        return res
          .status(200)
          .json(status.USER_ALREADY_EXISTS("User Alredy Exist", isUser));
      } else {
        const passwordHash = await hashPassword(UserData.password);
        const finalData = {
          ...UserData,
          fullName: name,
          password: passwordHash,
        };
        const RoleId = await UserRepositoryMongo.getRoleId("user");
        const Users = await UserRepositoryMongo.addUserInDashboard(finalData);
        const SaveUserRoleData = await UserRepositoryMongo.InsertUserRole({
          userId: Users?._id,
          roleId: RoleId,
        });
        return res
          .status(200)
          .json(status.SUCCESS("User created Successfully.", Users));
      }
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static DeleteUser = async (req, res) => {
    try {
      const { id, user_id } = req.query;

      console.log("params data---------------------", id, user_id);
      const UserStatus = await UserRepositoryMongo.DeleteUser(id, user_id);
      console.log("user status----------", UserStatus);
      return res.status(200).json(status.SUCCESS("User Deleted", UserStatus));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static UpdateUser = async (req, res) => {
    try {
      const { userId } = req.query;
      const User = req.body;
      console.log("params data---------------------", User);
      const UserStatus = await UserRepositoryMongo.updatedUser(userId, User);
      return res.status(200).json(status.SUCCESS("User Updated", UserStatus));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static getProfile = async (req, res) => {
    try {
      const userId = req.query?.userId;

      if (!userId) {
        return res.status(400).json(status.BAD_REQUEST("User ID is required"));
      }

      const user = await UserModel.findById(userId).select(
        " fullName email mobile"
      );

      console.log("user data----------", user);
      if (!user) {
        return res.status(404).json(status.NOT_FOUND("User not found"));
      }
      return res
        .status(200)
        .json(status.SUCCESS("User fetched successfully", user));
    } catch (error) {
      return res.status(500).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static UpdateProfile = async (req, res) => {
    try {
      const { fullName, email, mobile, updatedBy } = req.body;
      if (!fullName && !email && !mobile) {
        return res
          .status(400)
          .json(status.BAD_REQUEST("At least one field is required to update"));
      }
      const updateData = {};
      if (fullName) updateData.fullName = fullName;
      if (email) updateData.email = email;
      if (mobile) updateData.mobile = mobile;
      const updatedUser = await UserModel.findByIdAndUpdate(
        updatedBy,
        {
          $set: updateData,

          updatedDate: new Date(),
          updatedby: updatedBy,
        },
        { new: true }
      );
      console.log("updated user data----------", updatedUser);
      if (!updatedUser) {
        return res.status(404).json(status.NOT_FOUND("User not found"));
      }
      return res
        .status(200)
        .json(status.SUCCESS("Profile updated successfully", updatedUser));
    } catch (error) {
      return res.status(500).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static ChangePassword = async (req, res) => {
    try {
      const { userId, password } = req.body;
      console.log(req.body);
      const NewPassword = await hashPassword(password);
      console.log("new password----------", NewPassword);
      const UserStatus = await UserRepositoryMongo.UpdatePassword(
        userId,
        NewPassword
      );
      return res
        .status(200)
        .json(status.SUCCESS("Password Updated Successfully", UserStatus));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static ForgotPassword = async (req, res) => {
    try {
      const { userId } = req.query;
      const User = req.body;
      console.log("params data---------------------", User);
      const UserStatus = await UserRepositoryMongo.updatedUser(userId, User);
      return res.status(200).json(status.SUCCESS("User Updated", UserStatus));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static getUserDropdown = async (req, res) => {
    try {
      const UserStatus = await UserRepositoryMongo.getUserListDropdown();
      res.status(200).json(status.SUCCESS("User fetched.", UserStatus));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static addTask = async (req, res) => {
    try {
      const { name, description, targetdate, assignto, createdBy, priority } =
        req.body;
      const taskcount = await taskRepositiories.TaskCount();
      const taskid = await TaskId(taskcount);
      const finalData = {
        taskid: taskid,
        name: name,
        details: description,
        targetdate: targetdate,
        assignto: assignto,
        createdby: createdBy,
        priority: priority,
      };
      await taskRepositiories.addTask(finalData);

      return res.status(200).json(status.SUCCESS("Task updated", finalData));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static getTask = async (req, res) => {
    try {
      const { userId, userType } = req.query;

      console.log("user id---------in task ", userId, userType);
      let allTask;
      if (userType === "Admin" || userType === "SuperAdmin") {
        console.log("if block");
        allTask = await taskRepositiories.getTask();
      } else {
        console.log("else block");
        allTask = await UserRepositoryMongo.getReportingUsersTasks(userId);
        console.log("all task data----------", allTask);
      }

      return res.status(200).json(status.SUCCESS("Task updated", allTask));
    } catch (err) {
      res.status(500).send({
        messege: "Server error",
        error: err,
      });
    }
  };

  static getMyTask = async (req, res) => {
    try {
      const { userType, userId } = req.query;
      console.log("user id---------in my task ", userId, userType);
      let allTask;
      // if (userType === "Admin" || userType === "SuperAdmin") {
      //   allTask = await taskRepositiories.getAllTaskCount(userId);
      // } else {
      // }

      allTask = await taskRepositiories.getMyTaskCount(userId);
      res.status(200).send({
        messege: "Task fetched",
        data: allTask,
      });
    } catch (err) {
      res.status(500).send({
        messege: "Server error",
        error: err,
      });
    }
  }; // dashboard task for user

  static getTeamTask = async (req, res) => {
    try {
      const { userId, userType } = req.query;
      if (!userId || !userType) {
        return res
          .status(400)
          .json(status.BAD_REQUEST("User ID and User Type are required"));
      }
      const teamtask = await taskRepositiories.getTeamTask(userId, userType);
      // if (!teamtask || teamtask.length === 0) {
      //   return res.status(200).json(status.SUCCESS("No tasks found for the team",teamtask));
      // }
      // console.log("team task data----------", teamtask);
      return res
        .status(200)
        .json(status.SUCCESS("Team tasks fetched", teamtask));
    } catch (error) {
      console.error("Error in getTeamTask:", error);
      return res.status(500).json(status.SERVER_ERROR("Server side error"));
    }
  }; // dashboard task of team seen by user  work: In Progress

  static getTaskByTaskId = async (req, res) => {
    try {
      const { id } = req.query;
      const TaskStatus = await taskRepositiories.getSingleTask(id);
      const CurrentTaskNotes = await taskRepositiories.getCurrentNotesOfTask(
        id
      );
      return res.status(200).json(
        status.SUCCESS("Task fetched", {
          task: TaskStatus,
          notes: CurrentTaskNotes,
        })
      );
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static addTaskStatus = async (req, res) => {
    try {
      console.log("api hits");
      const { name } = req.body;
      const TaskStatus = await taskRepositiories.addTaskStatus({ name: name });
      console.log("task status-------", TaskStatus);
      res.status(200).send({
        messege: "task created",
        data: TaskStatus,
      });
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static getTaskStatus = async (req, res) => {
    try {
      const TaskStatus = await TaskStatusModal.find();
      res.status(200).send({
        messege: "task status fetched",
        data: TaskStatus,
      });
    } catch (err) {
      res.status(500).send({
        messege: "Server error",
        error: err,
      });
    }
  };

  static TaskStatusWise = async (req, res) => {
    try {
      const TaskStatus = await taskRepositiories.TaskStatusWise();
      return res.status(200).json(status.SUCCESS("Task Updated", TaskStatus));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static TaskStatusWiseCount = async (req, res) => {
    try {
      let TaskStatus;
      const { userId, userType } = req.query;
      console.log(userType);
      if (userType === "Admin" || userType === "SuperAdmin") {
        TaskStatus = await taskRepositiories.TaskStatusWiseCount();
      } else {
        TaskStatus = await taskRepositiories.TaskStatusWiseCountforUser(userId);
      }
      res.status(200).send({
        messege: "task status wise fetched",
        data: TaskStatus,
      });
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static DeleteTask = async (req, res) => {
    try {
      const { id, userId } = req.query;
      const TaskStatus = await taskRepositiories.DeleteTask(id, userId);
      const Tasklogs = await TaskLogsModal.create({
        taskid: id,
        description: "Task Deleted",
        performedBy: userId,
        actions: "Deleted",
        performedDate: new Date(),
      });
      return res
        .status(200)
        .json(status.SUCCESS("Task Statuse fetched", TaskStatus));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  }; // tasklog changes implemented

  static EditTask = async (req, res) => {
    try {
      const {
        assigntoId,
        details,
        statusId,
        remarks,
        id,
        updatedBy,
        priority,
      } = req.body;
      console.log("data in cont-----------", req.body);
      const data = {
        assigntoId: assigntoId,
        details: details,
        statusId: statusId,
        remarks: remarks,
        id: id,
        updatedBy: updatedBy,
        priority: priority,
      };

      console.log("data in cont-----------", data);
      const TaskStatus = await taskRepositiories.editTaskById(data);
      return res
        .status(200)
        .json(status.SUCCESS("Task updated error", TaskStatus));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static ReAssignTask = async (req, res) => {
    try {
      const { taskId, AssignToId, userId } = req.query;
      const datas = req.body;
      console.log("data in cont----------- for reasign", datas);
      const TaskStatus = await taskRepositiories.reAssignTask(
        taskId,
        AssignToId,
        userId
      );
      res.status(200).json(status.SUCCESS("Task Updated", TaskStatus));
    } catch (err) {
      res.status(500).json(status.SERVER_ERROR("Server Error", err));
    }
  };

  static changeTaskStatus = async (req, res) => {
    try {
      const { taskId, statusId, UserId } = req.query;
      const TaskStatus = await taskRepositiories.changeTaskStatus(
        taskId,
        statusId,
        UserId
      );
      res.status(200).json(status.SUCCESS("Task Updated", TaskStatus));
    } catch (err) {
      res.status(500).json(status.SERVER_ERROR("Server Error", err));
    }
  };

  static addNotes = async (req, res) => {
    try {
      const { taskId, notes, userId } = req.body;

      console.log("notes-----------", req.body);
      const taskcount = await taskRepositiories.NotesCount();
      const noteIds = await NotesId(taskcount);
      const data = {
        taskid: taskId,
        notesId: noteIds,
        notes: notes,
        addedBy: userId,
      };
      const TaskStatus = await taskRepositiories.AddNotes(data);
      res.status(200).json(status.SUCCESS("Task Updated", TaskStatus));
    } catch (err) {
      res.status(500).json(status.SERVER_ERROR("Server Error", err));
    }
  };

  static getNotes = async (req, res) => {
    try {
      const { taskId } = req.query;

      console.log("taskId in get notes-----------", taskId);
      const TaskStatus = await taskRepositiories.getNotes(taskId);
      console.log("notes data----------", TaskStatus);
      res.status(200).json(status.SUCCESS("Task Updated", TaskStatus));
    } catch (err) {
      res.status(500).json(status.SERVER_ERROR("Server Error", err));
    }
  };

  static FirstTimeOpenUpdate = async (req, res) => {
    try {
      const { taskId } = req.query;
      const TaskStatus = await taskRepositiories.FirstTimeOpenRepo(taskId);
      res.status(200).json(status.SUCCESS("Task Updated", TaskStatus));
    } catch (err) {
      res.status(500).json(status.SERVER_ERROR("Server Error", err));
    }
  };

  static getCurrentNotes = async (req, res) => {
    try {
      const { id } = req.query;
      const TaskStatus = await taskRepositiories.getCurrentNotesOfTask(id);
      return res.status(200).json(status.SUCCESS("Task fetched", TaskStatus));
    } catch (err) {
      return res.status(200).json(status.SERVER_ERROR("Server side error"));
    }
  };

  static getReportTaskWise = async (req, res) => {
    try {
      const { userType, userId } = req.query;
      console.log("user id---------", userType);
      let allTask;
      if (userType === "Admin" || userType === "SuperAdmin") {
        console.log("if block");
        allTask = await taskRepositiories.getReportTaskwiseAdmin();
      } else {
        console.log("else block");
        allTask = await taskRepositiories.getReportTaskwiseUser(userId);
      }
      return res.status(200).json(status.SUCCESS("Task updated", allTask));
    } catch (err) {
      res.status(500).send({
        messege: "Server error",
        error: err,
      });
    }
  };

  static getUserListCustom = async (req, res) => {
    try {
      const userId = req.query.userId;
      if (!userId) {
        return res.status(400).json(status.BAD_REQUEST("User ID is required"));
      }
      console.log("user id---------", userId);
      const allUser = await UserRepositoryMongo.getUserListCustom(userId);
      // console.log("all user data----------", allUser);
      return res.status(200).json(status.SUCCESS("User updated", allUser));
    } catch (err) {
      res.status(500).send({
        messege: "Server error",
        error: err,
      });
    }
  }; // removes superadmin from user list

  static getUserTaskReport = async (req, res) => {
    try {
      const { userType, userId, teamId } = req.query;

      if (!userId || !userType) {
        return res.status(400).json({
          success: false,
          message: "Missing required userId or userType in query",
        });
      }

      const userObjectId = new mongoose.Types.ObjectId(userId);

      const superAdminRoles = await RoleModel.find(
        { isSuperAdmin: true },
        { _id: 1 }
      ).lean();
      const superAdminRoleIds = superAdminRoles.map((r) => r._id.toString());

      const userMatch = {
        isDeleted: false,
        _id: { $ne: userObjectId },
        userType: { $nin: superAdminRoleIds },
      };

      if (teamId && teamId.length === 24) {
        userMatch.department = teamId; // assuming department is team
      }

      const users = await UserModel.aggregate([
        { $match: userMatch },

        // Convert department to ObjectId for lookup
        {
          $addFields: {
            departmentObjId: {
              $cond: [
                {
                  $and: [
                    { $eq: [{ $type: "$department" }, "string"] },
                    { $eq: [{ $strLenCP: "$department" }, 24] },
                  ],
                },
                { $toObjectId: "$department" },
                null,
              ],
            },
          },
        },

        // Lookup Team Name
        {
          $lookup: {
            from: "teams",
            localField: "departmentObjId",
            foreignField: "_id",
            as: "team",
          },
        },
        { $unwind: { path: "$team", preserveNullAndEmptyArrays: true } },

        // Convert designation to ObjectId for lookup
        {
          $addFields: {
            designationObjId: {
              $cond: [
                {
                  $and: [
                    { $eq: [{ $type: "$designation" }, "string"] },
                    { $eq: [{ $strLenCP: "$designation" }, 24] },
                  ],
                },
                { $toObjectId: "$designation" },
                null,
              ],
            },
          },
        },

        // Lookup Designation Name
        {
          $lookup: {
            from: "designations",
            localField: "designationObjId",
            foreignField: "_id",
            as: "designationInfo",
          },
        },
        {
          $unwind: {
            path: "$designationInfo",
            preserveNullAndEmptyArrays: true,
          },
        },

        // Lookup and process tasks assigned to this user
        {
          $lookup: {
            from: "tasks",
            let: { uid: "$_id" },
            pipeline: [
              {
                $match: {
                  $expr: {
                    $and: [
                      { $eq: ["$isDeleted", false] },
                      { $eq: [{ $toObjectId: "$assignto" }, "$$uid"] },
                    ],
                  },
                },
              },
              {
                $addFields: {
                  statusObjId: {
                    $cond: [
                      {
                        $and: [
                          { $eq: [{ $type: "$Taskstatus" }, "string"] },
                          { $eq: [{ $strLenCP: "$Taskstatus" }, 24] },
                        ],
                      },
                      { $toObjectId: "$Taskstatus" },
                      null,
                    ],
                  },
                },
              },
              {
                $lookup: {
                  from: "taskstatuses",
                  localField: "statusObjId",
                  foreignField: "_id",
                  as: "statusInfo",
                },
              },
              {
                $unwind: {
                  path: "$statusInfo",
                  preserveNullAndEmptyArrays: true,
                },
              },
              {
                $project: {
                  status: "$statusInfo.name",
                },
              },
            ],
            as: "userTasks",
          },
        },

        // Count tasks
        {
          $addFields: {
            totalTasks: { $size: "$userTasks" },
            completedTasks: {
              $size: {
                $filter: {
                  input: "$userTasks",
                  as: "task",
                  cond: { $eq: ["$$task.status", "Completed"] },
                },
              },
            },
            pendingTasks: {
              $size: {
                $filter: {
                  input: "$userTasks",
                  as: "task",
                  cond: {
                    $in: [
                      "$$task.status",
                      ["In Progress", "Not Started", "OverDue"],
                    ],
                  },
                },
              },
            },
          },
        },

        // Final projection
        {
          $project: {
            _id: 0,
            userId: "$_id",
            name: "$fullName",
            designation: "$designationInfo.name", // ✅ designation name
            department: "$team.name", // ✅ team name
            totalTasks: 1,
            completedTasks: 1,
            pendingTasks: 1,
          },
        },
      ]);

      return res.status(200).json({
        success: true,
        message: "User-wise task summary fetched successfully",
        data: users,
      });
    } catch (error) {
      console.error("Error in getUserTaskReport:", error);
      return res.status(500).json({
        success: false,
        message: "Internal server error",
        error: error.message,
      });
    }
  };

  static getRecentTask = async (req, res) => {
    try {
      const userType = req.query.userType;
      const userId = req.query.userId;

      const now = new Date();
      const twoDaysAgo = new Date();
      twoDaysAgo.setDate(now.getDate() - 2);

      const matchConditions = {
        $expr: { $eq: [{ $strLenCP: "$Taskstatus" }, 24] },
        isDeleted: false,
      };

      if (userType === "User" && userId) {
        matchConditions.$and = [
          {
            $or: [
              { createdDate: { $gte: twoDaysAgo, $lt: now } },
              { updatedDate: { $gte: twoDaysAgo, $lt: now } },
            ],
          },
          {
            $or: [{ assignto: userId }, { createdBy: userId }],
          },
        ];
      } else {
        matchConditions.$or = [
          { createdDate: { $gte: twoDaysAgo, $lt: now } },
          { updatedDate: { $gte: twoDaysAgo, $lt: now } },
        ];
      }

      const tasks = await TaskModal.aggregate([
        { $match: matchConditions },
        {
          $addFields: {
            TaskstatusObjectId: { $toObjectId: "$Taskstatus" },
          },
        },
        {
          $lookup: {
            from: "taskstatuses",
            localField: "TaskstatusObjectId",
            foreignField: "_id",
            as: "tasksStatusInfo",
          },
        },
        {
          $unwind: {
            path: "$tasksStatusInfo",
            preserveNullAndEmptyArrays: true,
          },
        },
        { $sort: { createdDate: -1 } },
        {
          $project: {
            _id: 1,
            taskid: 1,
            name: 1,
            createdDate: 1,
            updatedDate: {
              $cond: {
                if: { $gt: ["$updatedDate", null] },
                then: "$updatedDate",
                else: "$createdDate",
              },
            },
            Taskstatus: "$tasksStatusInfo.name",
          },
        },
      ]);

      res.status(200).json({ data: tasks });
    } catch (err) {
      console.error("Error in getRecentTask:", err);
      res.status(500).json({ message: "Error fetching recent tasks", err });
    }
  };

  // get recent tasks in last 2 days completed

  static getTaskStatusChart = async (req, res) => {
    try {
      const { userId, filter } = req.query;
      console.log("userId and filter type:", userId, filter);

      if (!filter) {
        return res.status(400).json({
          success: false,
          message: "Missing filter type (day/week/month)",
        });
      }

      const now = new Date();
      let startDate;
      let groupFormat;

      // Set date range and group format
      if (filter === "day") {
        startDate = new Date();
        startDate.setHours(0, 0, 0, 0);
        groupFormat = {
          year: { $year: "$createdDate" },
          month: { $month: "$createdDate" },
          day: { $dayOfMonth: "$createdDate" },
        };
      } else if (filter === "week") {
        const weekAgo = new Date();
        weekAgo.setDate(now.getDate() - 6);
        weekAgo.setHours(0, 0, 0, 0);
        startDate = weekAgo;
        groupFormat = {
          year: { $year: "$createdDate" },
          month: { $month: "$createdDate" },
          day: { $dayOfMonth: "$createdDate" },
        };
      } else {
        const monthsAgo = new Date();
        monthsAgo.setMonth(now.getMonth() - 5);
        monthsAgo.setHours(0, 0, 0, 0);
        startDate = monthsAgo;
        groupFormat = {
          year: { $year: "$createdDate" },
          month: { $month: "$createdDate" },
        };
      }

      const matchCondition = {
        isDeleted: false,
        createdDate: { $gte: startDate },
      };

      if (userId) {
        matchCondition.assignto = userId;
      }

      const taskData = await TaskModal.aggregate([
        // Match tasks within date range
        {
          $match: {
            ...matchCondition,
            $expr: { $eq: [{ $strLenCP: "$Taskstatus" }, 24] },
          },
        },

        // Convert Taskstatus string to ObjectId
        {
          $addFields: {
            TaskstatusObjectId: { $toObjectId: "$Taskstatus" },
          },
        },

        // Join with taskstatuses collection
        {
          $lookup: {
            from: "taskstatuses",
            localField: "TaskstatusObjectId",
            foreignField: "_id",
            as: "statusInfo",
          },
        },

        // Flatten statusInfo array
        {
          $unwind: {
            path: "$statusInfo",
            preserveNullAndEmptyArrays: true,
          },
        },

        // Group by date, status name, and priority
        {
          $group: {
            _id: {
              ...groupFormat,
              status: "$statusInfo.name",
              priority: "$priority",
            },
            count: { $sum: 1 },
          },
        },

        // Regroup by date only
        {
          $group: {
            _id: {
              year: "$_id.year",
              month: "$_id.month",
              ...(filter !== "month" && { day: "$_id.day" }),
            },
            statusGroups: {
              $push: {
                status: "$_id.status",
                count: "$count",
              },
            },
            severityGroups: {
              $push: {
                priority: "$_id.priority",
                count: "$count",
              },
            },
          },
        },

        // Sort by date
        {
          $sort: {
            "_id.year": 1,
            "_id.month": 1,
            ...(filter !== "month" && { "_id.day": 1 }),
          },
        },
      ]);

      // Format final output
      const result = taskData.map((entry) => {
        const { year, month, day } = entry._id;
        const dateObj = new Date(year, month - 1, day || 1);

        const label =
          filter === "month"
            ? dateObj.toLocaleString("default", {
                month: "short",
                year: "numeric",
              })
            : filter === "week"
            ? dateObj.toLocaleDateString("default", {
                weekday: "short",
                day: "numeric",
                month: "short",
              })
            : "Today";

        const defaultStatuses = {
          Completed: 0,
          "In Progress": 0,
          "Not Started": 0,
          OverDue: 0,
        };

        const defaultSeverities = {
          High: 0,
          Medium: 0,
          Low: 0,
        };

        for (const s of entry.statusGroups) {
          if (s.status && defaultStatuses.hasOwnProperty(s.status)) {
            defaultStatuses[s.status] = s.count;
          }
        }

        for (const p of entry.severityGroups) {
          if (p.priority && defaultSeverities.hasOwnProperty(p.priority)) {
            defaultSeverities[p.priority] = p.count;
          }
        }

        return {
          label,
          statuses: defaultStatuses,
          severities: defaultSeverities,
        };
      });

      return res.status(200).json({
        success: true,
        message: "Chart data fetched successfully",
        data: result,
      });
    } catch (error) {
      console.error("Error in getTaskStatusChartData:", error);
      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
        error: error.message,
      });
    }
  };
  // work: In Progress

  static updateUserStatus = async (req, res) => {
    try {
      const { userId, isActive } = req.body;
      console.log("Updating user status:", userId, isActive);

      if (!userId || typeof isActive !== "boolean") {
        return res.status(400).json({
          success: false,
          message: "Missing or invalid userId or isActive flag",
        });
      }

      const updatedUser = await UserModel.findByIdAndUpdate(
        userId,
        { isActive },
        { new: true }
      );

      if (!updatedUser) {
        return res.status(404).json({
          success: false,
          message: "User not found",
        });
      }

      res.status(200).json({
        success: true,
        message: `User status updated to ${isActive ? "Active" : "Inactive"}`,
        data: updatedUser,
      });
    } catch (error) {
      console.error("Error updating user status:", error);
      res.status(500).json({
        success: false,
        message: "Server error",
      });
    }
  };

  static DumpReport = async (req, res) => {
    try {
      const { fromDate, toDate } = req.body;
      console.log("Dump Report request received with dates:", fromDate, toDate);
      if (!fromDate || !toDate) {
        return res.status(400).json({
          success: false,
          message: "Both fromDate and toDate are required",
        });
      }

      const dumpReport = await UserRepositoryMongo.getDumpReport(
        fromDate,
        toDate
      );
      console.log("Dump Report data:", dumpReport);
      if (!dumpReport || dumpReport.length === 0) {
        return res.status(404).json({
          success: false,
          message: "No data found for the given date range",
        });
      }
      return res.status(200).json({
        success: true,
        message: "Dump Report fetched successfully",
        data: dumpReport,
      });
    } catch (error) {
      console.error("Error in DumpReport:", error);
      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
        error: error.message,
      });
    }
  };

  static uploadFile = async (req, res) => {
    try {
      const { taskid, uploadedBy, remarks } = req.body;

      console.log(
        "File upload request received:",
        req.file?.originalname,
        taskid,
        uploadedBy,
        remarks
      );

      if (!req.file) {
        return res.status(400).json({
          success: false,
          message: "No file uploaded",
        });
      }

      // Construct file URL
      const fileurl = `/uploads/${req.file.filename}`;

      // Save metadata to DB
      const newAttachment = new TaskAttachmentModal({
        taskid,
        filename: req.file.originalname,
        filetype: req.file.mimetype,
        fileurl,
        uploadedBy,
        remarks: remarks || null,
      });

      const newlog = new TaskLogsModal({
        taskid: taskid,
        description: `File uploaded: ${req.file.originalname}`,
        performedBy: uploadedBy,
        actions: "Document related",
        performedDate: new Date(),
      });

      await newAttachment.save();
      await newlog.save();

      return res.status(201).json({
        success: true,
        message: "File uploaded and saved successfully",
        data: newAttachment,
      });
    } catch (error) {
      console.error("Error uploading file:", error);

      // 🧹 Delete uploaded file if DB save fails
      if (req.file) {
        const filePath = path.join(
          __dirname,
          "../../uploads",
          req.file.filename
        );
        fs.unlink(filePath, (err) => {
          if (err) {
            console.error("Error deleting failed upload:", err.message);
          } else {
            console.log("⛔ File deleted due to DB error.");
          }
        });
      }

      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
        error: error.message,
      });
    }
  };

  static getFileById = async (req, res) => {
    try {
      const { id } = req.query;
      console.log("Fetching attachments for task ID:", id);

      if (!id || !mongoose.Types.ObjectId.isValid(id)) {
        return res.status(400).json({
          success: false,
          message: "Valid Task ID is required",
        });
      }

      const attachments = await TaskAttachmentModal.aggregate([
        {
          $match: {
            taskid: new mongoose.Types.ObjectId(id), // ✅ Ensure ObjectId match
          },
        },
        {
          $addFields: {
            uploadedByObjectId: {
              $convert: {
                input: "$uploadedBy",
                to: "objectId",
                onError: null,
                onNull: null,
              },
            },
          },
        },
        {
          $lookup: {
            from: "users", // ✅ should match collection name
            localField: "uploadedByObjectId",
            foreignField: "_id",
            as: "userDetails",
          },
        },
        {
          $unwind: {
            path: "$userDetails",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $sort: { uploadedDate: -1 },
        },
        {
          $project: {
            _id: 1,
            filename: 1,
            filetype: 1,
            fileurl: 1,
            uploadedDate: 1,
            remarks: 1,
            uploadedBy: {
              $ifNull: ["$userDetails.fullName", "$uploadedBy"], // fallback to ID if no match
            },
          },
        },
      ]);

      if (!attachments || attachments.length === 0) {
        return res.status(200).json({
          success: true,
          message: "No attachments found for this task",
          data: [],
        });
      }

      return res.status(200).json({
        success: true,
        message: "Attachments fetched successfully",
        data: attachments,
      });
    } catch (error) {
      console.error("Error fetching file:", error);

      // Optional cleanup if file was uploaded earlier but operation failed
      if (req.file) {
        const filePath = path.join(__dirname, "../uploads", req.file.filename);
        fs.unlink(filePath, (unlinkErr) => {
          if (unlinkErr)
            console.error("Error deleting file:", unlinkErr.message);
          else console.log("File deleted due to error.");
        });
      }

      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
        error: error.message,
      });
    }
  }; // work to be done uploadedby need to added

  static viewFile = async (req, res) => {
    try {
      const { id } = req.query;
      console.log("Viewing file with ID:", id);

      if (!id) {
        return res.status(400).json({
          success: false,
          message: "Attachment ID is required",
        });
      }

      const attachment = await TaskAttachmentModal.findById(id);
      if (!attachment) {
        return res.status(404).json({
          success: false,
          message: "Attachment not found",
        });
      }

      const filePath = getLocalFilePath(attachment.fileurl);
      console.log("File path to view:", filePath);

      res.sendFile(filePath, (err) => {
        if (err) {
          console.error("Error sending file:", err);
          return res.status(500).json({
            success: false,
            message: "Error viewing file",
            error: err.message,
          });
        }
      });
    } catch (error) {
      console.error("Error in viewFile:", error);
      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
        error: error.message,
      });
    }
  };
  static downloadFile = async (req, res) => {
    try {
      const { id } = req.query;
      console.log("Downloading file with ID:", id);

      if (!id) {
        return res.status(400).json({
          success: false,
          message: "Attachment ID is required",
        });
      }

      const attachment = await TaskAttachmentModal.findById(id);
      if (!attachment) {
        return res.status(404).json({
          success: false,
          message: "Attachment not found",
        });
      }

      const filePath = getLocalFilePath(attachment.fileurl);
      console.log("File path to download:", filePath);

      res.download(filePath, attachment.filename, (err) => {
        if (err) {
          console.error("Error downloading file:", err);
          return res.status(500).json({
            success: false,
            message: "Error downloading file",
            error: err.message,
          });
        }
      });
    } catch (error) {
      console.error("Error in downloadFile:", error);
      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
        error: error.message,
      });
    }
  };

  static deleteFile = async (req, res) => {
    try {
      const { id } = req.query;
      console.log("Deleting file with ID:", id);

      if (!id) {
        return res.status(400).json({
          success: false,
          message: "Attachment ID is required",
        });
      }

      const attachment = await TaskAttachmentModal.findByIdAndDelete(id);
      if (!attachment) {
        return res.status(404).json({
          success: false,
          message: "Attachment not found",
        });
      }

      // Delete the file from the filesystem
      const filePath = getLocalFilePath(attachment.fileurl);
      fs.unlink(filePath, (err) => {
        if (err) {
          console.error("Error deleting file from filesystem:", err);
          return res.status(500).json({
            success: false,
            message: "Error deleting file from filesystem",
            error: err.message,
          });
        }
        return res.status(200).json({
          success: true,
          message: "File deleted successfully",
        });
      });
    } catch (error) {
      console.error("Error in deleteFile:", error);
      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
        error: error.message,
      });
    }
  };

  static getTaskLogs = async (req, res) => {
    try {
      const { taskid } = req.query;
      console.log("Fetching task logs for task ID:", taskid);
      if (!taskid) {
        return res.status(400).json({
          success: false,
          message: "Task ID is required",
        });
      }
      const result = await taskRepositiories.getTaskLogs(taskid);
      // console.log("Task logs fetched:", result);
      if (!result || result.length === 0) {
        return res.status(200).json({
          success: false,
          message: "No logs found for this task",
        });
      }

      return res.status(200).json({
        success: true,
        message: "Task logs fetched successfully",
        data: result,
      });
    } catch (error) {
      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
        error: error.message,
      });
    }
  };

  static getUserforTeamAssign = async (req, res) => {
    try {
      const userlist = await UserModel.aggregate([
        {
          $match: {
            isDeleted: false,
            $or: [
              { department: "" },
              { department: null },
              { department: { $exists: false } },
            ],
          },
        },
        // Convert string userType to ObjectId for join
        {
          $addFields: {
            userTypeObjId: { $toObjectId: "$userType" },
          },
        },
        // Lookup role information based on ObjectId
        {
          $lookup: {
            from: "roles", // your RoleModel collection
            localField: "userTypeObjId",
            foreignField: "_id",
            as: "roleInfo",
          },
        },
        {
          $unwind: {
            path: "$roleInfo",
            preserveNullAndEmptyArrays: false,
          },
        },
        // Exclude users where isSuperAdmin === true
        {
          $match: {
            "roleInfo.isSuperAdmin": { $ne: true },
          },
        },
        {
          $project: {
            _id: 1,
            fullName: 1,
            email: 1,
            department: 1,
            designation: 1,
            userType: 1,
            role: "$roleInfo.name",
          },
        },
      ]);

      if (!userlist || userlist.length === 0) {
        return res.status(201).json({
          success: true,
          message: "No users found for team assignment",
        });
      }

      return res.status(200).json({
        success: true,
        message: "Users fetched successfully",
        data: userlist,
      });
    } catch (error) {
      console.error("Error in getUserforTeamAssign:", error);
      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
        error: error.message,
      });
    }
  };

  // Department section

  static createDepartment = async (req, res) => {
    try {
      const { name } = req.body;
      if (!name) {
        return res.status(400).json({
          success: false,
          message: "Name is required",
        });
      }
      console.log("Creating department with data:", req.body);

      const newDepartment = new DepartmentModel({
        name: name,
      });
      const savedDepartment = await newDepartment.save();
      console.log("Department created successfully:", savedDepartment);
      return res.status(201).json({
        success: true,
        message: "Department created successfully",
        data: savedDepartment,
      });
    } catch (error) {
      console.error("Error in createDepartment:", error);
      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
        error: error.message,
      });
    }
  };
  static getDepartment = async (req, res) => {
    try {
      const departments = await DepartmentModel.find({
        isDeleted: false,
      }).lean();
      // console.log("Fetching departments:", departments);
      if (!departments || departments.length === 0) {
        return res.status(404).json({
          success: false,
          message: "No departments found",
        });
      }
      return res.status(200).json({
        success: true,
        message: "Departments fetched successfully",
        data: departments,
      });
    } catch (error) {
      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
        error: error.message,
      });
    }
  };

  // analytic section

  static getStatusSummary = async (req, res) => {
    try {
      console.log("Fetching task status summary...");

      const summary = await TaskModal.aggregate([
        {
          $match: { isDeleted: false },
        },
        {
          $addFields: {
            taskStatusObjId: {
              $toObjectId: "$Taskstatus",
            },
          },
        },
        {
          $lookup: {
            from: "taskstatuses",
            localField: "taskStatusObjId",
            foreignField: "_id",
            as: "statusInfo",
          },
        },
        {
          $unwind: {
            path: "$statusInfo",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $group: {
            _id: "$statusInfo.name",
            count: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ]);

      console.log("Task status summary:", summary);

      // Default result structure
      const result = {
        "Not Started": 0,
        "In Progress": 0,
        Completed: 0,
        Discarded: 0,
      };

      summary.forEach((item) => {
        const key = item._id || "Unknown";
        result[key] = item.count;
      });
      console.log("Formatted result:", result);

      res.json({ statusCode: 200, data: result });
    } catch (error) {
      console.error("Error in getStatusSummary:", error);
      res
        .status(500)
        .json({ statusCode: 500, message: "Internal server error" });
    }
  };
  static getTaskTrend = async (req, res) => {
    try {
      const range = req.query.range || "7d";
      const days = parseInt(range.replace("d", "")) || 7;

      // Get the start date N days ago at 00:00:00
      const today = new Date();
      const startDate = new Date(today);
      startDate.setDate(today.getDate() - (days - 1));
      startDate.setHours(0, 0, 0, 0);

      // Fetch trend from DB
      const trend = await TaskModal.aggregate([
        {
          $match: {
            isDeleted: false,
            createdDate: { $gte: startDate },
          },
        },
        {
          $group: {
            _id: {
              $dateToString: {
                format: "%Y-%m-%d",
                date: "$createdDate",
                timezone: "+05:30",
              },
            },
            count: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ]);

      // Fill missing dates with count = 0
      const trendData = [];
      for (let i = 0; i < days; i++) {
        const date = new Date(startDate);
        date.setDate(startDate.getDate() + i);
        const isoDate = date.toISOString().slice(0, 10); // Format: YYYY-MM-DD

        const found = trend.find((t) => t._id === isoDate);
        trendData.push({ date: isoDate, count: found ? found.count : 0 });
      }

      res.json({ statusCode: 200, data: trendData });
    } catch (error) {
      console.error("Error in getTaskTrend:", error);
      res
        .status(500)
        .json({ statusCode: 500, message: "Internal server error" });
    }
  };
  static getTeamTasks = async (req, res) => {
    try {
      const teams = await TeamModel.find({ isDeleted: false }).lean();

      const finalResult = [];

      for (const team of teams) {
        // Step 1: Find users in this team
        const users = await UserModel.find(
          { department: team._id.toString() },
          "_id"
        ).lean();
        const userIds = users.map((user) => user._id.toString());

        if (userIds.length === 0) continue;

        // Step 2: Get task counts per status
        const taskStatusCounts = await TaskModal.aggregate([
          {
            $match: {
              isDeleted: false,
              assignto: { $in: userIds },
            },
          },
          {
            $addFields: {
              taskStatusObjId: {
                $toObjectId: "$Taskstatus",
              },
            },
          },
          {
            $lookup: {
              from: "taskstatuses",
              localField: "taskStatusObjId",
              foreignField: "_id",
              as: "statusInfo",
            },
          },
          { $unwind: "$statusInfo" },
          {
            $group: {
              _id: "$statusInfo.name",
              count: { $sum: 1 },
            },
          },
        ]);

        // Step 3: Default status map with OverDue
        const statusMap = {
          "Not Started": 0,
          "In Progress": 0,
          Completed: 0,
          Discarded: 0,
          OverDue: 0,
        };

        taskStatusCounts.forEach((entry) => {
          const status = entry._id;
          if (statusMap.hasOwnProperty(status)) {
            statusMap[status] = entry.count;
          }
        });

        // Step 4: Push result
        finalResult.push({
          teamId: team._id,
          teamName: team.name,
          ...statusMap,
        });
      }

      res.json({ statusCode: 200, data: finalResult });
    } catch (error) {
      console.error("Error in getTeamTasks:", error);
      res
        .status(500)
        .json({ statusCode: 500, message: "Internal server error" });
    }
  };

  // Notification section

  static getNotifications = async (req, res) => {
    try {
      const { userId } = req.query;
      console.log("Fetching notifications for userId:", userId);

      if (!userId || !mongoose.Types.ObjectId.isValid(userId)) {
        return res.status(400).json({
          success: false,
          message: "Valid userId is required",
        });
      }

      const notifications = await NotificationModal.find({
        recieverId: userId,
        isRead: false,
      })
        .populate("senderId", "fullName email")
        .populate("taskId", "name taskid")
        .sort({ createdAt: -1 })
        .limit(50);

      return res.status(200).json({
        success: true,
        notifications,
      });
    } catch (error) {
      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
        error: error.message,
      });
    }
  };
  static markNotificationAsRead = async (req, res) => {
    try {
      const { notificationId } = req.body;

      if (!notificationId || !mongoose.Types.ObjectId.isValid(notificationId)) {
        return res.status(400).json({
          success: false,
          message: "Valid notificationId is required",
        });
      }

      const updated = await NotificationModal.findByIdAndUpdate(
        notificationId,
        { isRead: true, readDate: new Date() },
        { new: true }
      );

      if (!updated) {
        return res.status(404).json({
          success: false,
          message: "Notification not found",
        });
      }

      return res.status(200).json({
        success: true,
        message: "Notification marked as read",
        notification: updated,
      });
    } catch (error) {
      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
        error: error.message,
      });
    }
  };
  static markAllNotificationsAsRead = async (req, res) => {
    try {
      const { userId } = req.body;

      if (!userId || !mongoose.Types.ObjectId.isValid(userId)) {
        return res.status(400).json({
          success: false,
          message: "Valid userId is required",
        });
      }

      const result = await NotificationModal.updateMany(
        { recieverId: userId, isRead: false },
        { isRead: true, readDate: new Date() }
      );

      return res.status(200).json({
        success: true,
        message: `${result.modifiedCount} notifications marked as read.`,
      });
    } catch (error) {
      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
        error: error.message,
      });
    }
  };
}

module.exports = UserController;
