const { status } = require("../../utils/statusSender");

class AdminController
{
   static TaskCount=async(req,res)=>{
    try {
        const TaskStatus = await taskRepositiories.TaskStatusWiseCount();
        res.status(200).send({
          messege: "task status wise fetched",
          data: TaskStatus,
        });
      } catch (err) {
        return res.status(200).json(status.SERVER_ERROR("Server side error"));
      }
   }


}


module.exports=AdminController