const UserRepository = require('../../repositories/mysqlRepositories/userRepositiries');
const UserRepositoryMongo = require('../../repositories/mongoRepositories/userRepositiries');
const {hashPassword,comparePassword}=require('../../services/encryptionService');
const {BearerToken} =require('../../utils/tokenGenerator');
const {status,STATUS_CODE} = require('../../utils/statusSender');
const { UserModel, RoleModel, UserRoleModel } = require('../../model/User/userModel');
class AuthController
{
   static UserRegistration=async(req,res)=>{
    try{
        const {fullName,email,password}=req.body;    
        if(!fullName || !email || !password)
        {
            res.status(209).jason(status.BAD_REQUEST())
        }
        else{
            const isUser=await UserRepositoryMongo.findeUserByEmail(email);        //check for existing user
            if(isUser){
                 return res.status(200).json(status.USER_ALREADY_EXISTS("A user with this email already exists."));
               
            }
            else{
                const passwordHash=await hashPassword(password);      //convert password to hash type

                const userData={
                fullName:fullName,
                email:email,
                password:passwordHash
                }
                const RoleId=await UserRepositoryMongo.getRoleId('user');
                console.log("userRoleId------",RoleId);

                const insertUser=await UserRepositoryMongo.InsertUserData(userData);   //save user
                console.log("insert user--------",insertUser);

                const SaveUserRoleData=await UserRepositoryMongo.InsertUserRole({userId:insertUser?._id,roleId:RoleId});   //save user role     
                console.log("Save user role",SaveUserRoleData);    
                    return res.status(200).json(status.SUCCESS("User created",insertUser));    
            }
        }
    }
    catch(err){
        return res.status(200).json(status.SERVER_ERROR("Server side error"));
    } 
   }

   static Userlogin=async(req,res)=>{
    try{
        const ipData=req.clientIp;
        const {email,password}=req.body;
        let LoginAuditData={
            userName:email,
            remoteIp:"127.0.0.1",
            Latittude:ipData.ll[0],
            Longitude:ipData.ll[1]
        }
        if(!email || !password)
            {
                const LoginAudit={...LoginAuditData,status:false};
                const login=await UserRepositoryMongo.InsertLoginAuditData(LoginAudit);  
                return res.status(500).json(status.ERROR("The field is required."));    
            }
            else{
                const isUser= await UserRepositoryMongo.findeUserByEmail(email);
                if(!isUser){
                    const LoginAudit={...LoginAuditData,status:false};
                    await UserRepositoryMongo.InsertLoginAuditData(LoginAudit);   
                    return res.status(200).json(status.NOT_FOUND("User not found")); 
                }
                else{
                    const isPasswordMatch=await comparePassword(password,isUser.password);
                    if(!isPasswordMatch){
                        const LoginAudit={...LoginAuditData,status:false};
                        await UserRepositoryMongo.InsertLoginAuditData(LoginAudit);   
                        return res.status(200).json(status.NOT_FOUND("Invalid User"));    
                    }
                    else{
                        const userData={
                            email:email,
                            name:isUser.firstName
                        }
                        const token=await BearerToken(userData);
                        const LoginAudit={...LoginAuditData,status:true};

                        const USerLoginDetails = {
                            ...LoginAuditData,
                            userId:isUser._id,
                            Token:token,
                            loginTime:Date.now()
                          };
                         const LoginUser=await UserRepositoryMongo.getLoginUser(email);
                        
                       await UserRepositoryMongo.InsertLoginAuditData(LoginAudit);
                       await UserRepositoryMongo.InsertLoginUser(USerLoginDetails);
                        return res.status(200).json(status.SUCCESS("Login successfull",{user:LoginUser,token:token}));    
                    }
                }  
            }
    }
    catch(err){
        return res.status(500).json(status.SERVER_ERROR(err));    
    }
     
   }


   static Logout=async(req,res)=>{
    try{
        const {Token}=req.body;
        // console.log("Token",Token);
        if(!Token){
            return res.status(200).json(status.BAD_REQUEST("User id is required"));    
        }
        else{
            const LoginuserDataUpdate =await UserRepositoryMongo.getLoginUserById(Token);
            // console.log("LoginuserDataUpdate",LoginuserDataUpdate);
            res.status(200).json(status.SUCCESS("User logout successfully",LoginuserDataUpdate));
            
        }
    }
    catch(err){
        return res.status(500).json(status.SERVER_ERROR(err));    

    } 
   }



   static AddRole=async(req,res)=>{
    try{
        const {name}=req.body;
        if(!name){
            res.status(201).json(status.USER_ALREADY_EXISTS("A user with this email already exists."));

        }
        else{
            const isRole=await UserRepositoryMongo.findRoleByName(name);
            console.log(isRole);
            if(isRole)
            {
                return res.status(409).json(status.USER_ALREADY_EXISTS("Role exist"));    
            }  
            const insertRole=await UserRepositoryMongo.InsertRole({name:name})
            console.log(insertRole);
            return res.status(200).json(status.SUCCESS("role created",insertRole));    
        }
    }
    catch(err){
        return res.status(500).json(status.SERVER_ERROR(err));    

    } 
   }

   static ChangeRole=async(req,res)=>{
    try {
        const {userEmail,roleName,userId}=req.body;
        if(!userEmail || !roleName){
            return res.status(400).json(status.BAD_REQUEST("User email and role name are required"));
        }
        const user = await UserModel.findOne({ email: userEmail });
        const role = await RoleModel.findOne({ name: roleName });
        if (!user || !role) {
            return res.status(404).json(status.NOT_FOUND("User or role not found"));
        }
       // Update the user's role

       const updatedUser = await UserModel.findByIdAndUpdate(
        user._id,
        {
            userType: role._id,
            updatedDate: new Date(),
            updatedby: userId // Assuming userId is the ID of the user making the change
        },
        { new: true }
       )
       console.log("updatedUser",updatedUser);

       const userRoleData = await UserRoleModel.findOneAndUpdate(
        {userId: user._id},
        {
            roleId: role._id,
        },
        {new: true}
       )

        console.log("userRoleData",userRoleData);

       if(!updatedUser || !userRoleData) {
            return res.status(500).json(status.SERVER_ERROR("Failed to update user role"));
        }

        return res.status(200).json(status.SUCCESS("User role updated successfully", { user: updatedUser, userRole: userRoleData }));
        
    } catch (error) {
        return res.status(500).json(status.SERVER_ERROR(error));
        
    }
   }

}
module.exports=AuthController; 