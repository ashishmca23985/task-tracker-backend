const mongoose = require("mongoose");
const {
  TaskStatusModal,
  TaskModal,
  TaskNotesModal,
} = require("../../model/User/taskModel");
const { stringToDate } = require("../../utils/service");
const { Types } = require("mysql2");
const { SaveCurrentDateAndTime } = require("../../utils/timeGenerator");
const { TaskLogsModal } = require("../../model/User/taskModel");
const { UserModel } = require("../../model/User/userModel");
const {NotificationModal} = require("../../model/User/taskModel");

class taskRepositiories {
  static addTaskStatus = async (taskData) => {
    console.log("taskdata-----------", taskData);
    const newTask = new TaskStatusModal(taskData);
    await newTask.save();
  };

  static addTask = async (taskData) => {
    try {
      // Save the new task first
      const newTask = new TaskModal(taskData);
      await newTask.save();
      console.log("New Task Created:", newTask);

      // Now create the task log using the saved task's _id
      const tasklog = await TaskLogsModal.create({
        taskid: newTask._id,
        actions: "Created", // enum value
        description: "Task Created",
        performedBy: taskData.createdby,
        performedDate: new Date(), // current date
        // 'when' will be auto-filled by timestamps
      });
      // console.log("Task Log Created:", tasklog);
       await NotificationModal.create({
        recieverId: taskData.assignto, // Assuming assignto is the user ID
        senderId: taskData.createdby, // Assuming createdby is the user ID
        taskId: newTask._id, // Use the newly created task's ID
        message: `New task "${newTask.name}" has been assigned to you.`,
      });
       



      return newTask;
    } catch (err) {
      console.error("Error in addTask:", err);
      throw err;
    }
  }; // addTask method to save task and log testing to be done

  static getTask = async () => {
    const tasksWithDetails = await TaskModal.aggregate([
      {
        $match: {
          isDeleted: false,
        },
      },
      {
        $addFields: {
          statusObjectId: { $toObjectId: "$Taskstatus" },
          assigntoObjectId: { $toObjectId: "$assignto" },
          createdByObjectId: { $toObjectId: "$createdby" }, // Convert createdby to ObjectId
        },
      },
      {
        $lookup: {
          from: "taskstatuses",
          localField: "statusObjectId",
          foreignField: "_id",
          as: "statusInfo",
        },
      },
      { $unwind: "$statusInfo" },

      {
        $lookup: {
          from: "users",
          localField: "assigntoObjectId",
          foreignField: "_id",
          as: "userInfo",
        },
      },
      { $unwind: "$userInfo" },

      {
        $lookup: {
          from: "users",
          localField: "createdByObjectId",
          foreignField: "_id",
          as: "createdByInfo",
        },
      },
      { $unwind: "$createdByInfo" },

      {
        $project: {
          _id: 1,
          taskid: 1,
          name: 1,
          details: 1,
          active: 1,
          status: "$statusInfo.name",
          assignto: "$userInfo.fullName",
          createdby: "$createdByInfo.fullName", // Get full name of creator
          createdDate: 1,
          targetdate: 1,
          priority: 1,
        },
      },
      {
        $sort: {
          _id: -1,
        },
      },
    ]);

    return tasksWithDetails;
  };

 static getReportTaskwiseAdmin = async () => {
  console.log("Fetching task report for admin...");
  const tasksWithDetails = await TaskModal.aggregate([
    {
      $match: { isDeleted: false },
    },
    {
      $addFields: {
        userObjId: {
          $convert: {
            input: "$assignto",
            to: "objectId",
            onError: null,
            onNull: null,
          },
        },
        taskStatusObjId: {
          $convert: {
            input: "$Taskstatus",
            to: "objectId",
            onError: null,
            onNull: null,
          },
        },
      },
    },
    {
      $lookup: {
        from: "users",
        localField: "userObjId",
        foreignField: "_id",
        as: "user",
      },
    },
    { $unwind: "$user" },
    {
      $addFields: {
        teamObjId: {
          $convert: {
            input: "$user.department",
            to: "objectId",
            onError: null,
            onNull: null,
          },
        },
        designationObjId: {
          $convert: {
            input: "$user.designation",
            to: "objectId",
            onError: null,
            onNull: null,
          },
        },
      },
    },
    {
      $lookup: {
        from: "teams",
        localField: "teamObjId",
        foreignField: "_id",
        as: "team",
      },
    },
    { $unwind: { path: "$team", preserveNullAndEmptyArrays: true } },
    {
      $lookup: {
        from: "designations",
        localField: "designationObjId",
        foreignField: "_id",
        as: "designation",
      },
    },
    { $unwind: { path: "$designation", preserveNullAndEmptyArrays: true } },
    {
      $lookup: {
        from: "taskstatuses",
        localField: "taskStatusObjId",
        foreignField: "_id",
        as: "status",
      },
    },
    { $unwind: "$status" },
    {
      $group: {
        _id: "$user._id",
        name: { $first: "$user.fullName" },
        department: { $first: "$team.name" },
        designation: { $first: "$designation.name" },
        totalTasks: { $sum: 1 },
        completedTasks: {
          $sum: {
            $cond: [{ $eq: ["$status.name", "Completed"] }, 1, 0],
          },
        },
        pendingTasks: {
          $sum: {
            $cond: [{ $eq: ["$status.name", "In Progress"] }, 1, 0],
          },
        },
        notStartedTasks: {
          $sum: {
            $cond: [{ $eq: ["$status.name", "Not Started"] }, 1, 0],
          },
        },
        discardedTasks: {
          $sum: {
            $cond: [{ $eq: ["$status.name", "Discarded"] }, 1, 0],
          },
        },
        overdueTasks: {
          $sum: {
            $cond: [
              {
                $and: [
                  { $eq: ["$status.name", "In Progress"] },
                  { $lt: ["$targetdate", new Date()] },
                ],
              },
              1,
              0,
            ],
          },
        },
      },
    },
  ]);

  console.log("tasksWithDetails------------", tasksWithDetails);
  return tasksWithDetails;
};


  static getReportTaskwiseUser = async (userId) => {
    const tasksWithDetails = await TaskModal.aggregate([
      {
        $match: { assignto: userId }, // Since assignto is a string
        isDeleted: false,
      },
      {
        $addFields: {
          userObjId: { $toObjectId: "$assignto" },
          taskStatusObjId: { $toObjectId: "$Taskstatus" },
        },
      },
      // Lookup user
      {
        $lookup: {
          from: "users",
          localField: "userObjId",
          foreignField: "_id",
          as: "user",
        },
      },
      { $unwind: "$user" },
      // Convert department and designation to ObjectId
      {
        $addFields: {
          teamObjId: { $toObjectId: "$user.department" },
          designationObjId: { $toObjectId: "$user.designation" },
        },
      },
      // Lookup team
      {
        $lookup: {
          from: "teams",
          localField: "teamObjId",
          foreignField: "_id",
          as: "team",
        },
      },
      { $unwind: { path: "$team", preserveNullAndEmptyArrays: true } },
      // Lookup designation
      {
        $lookup: {
          from: "designations",
          localField: "designationObjId",
          foreignField: "_id",
          as: "designation",
        },
      },
      { $unwind: { path: "$designation", preserveNullAndEmptyArrays: true } },
      // Lookup taskstatus
      {
        $lookup: {
          from: "taskstatuses",
          localField: "taskStatusObjId",
          foreignField: "_id",
          as: "status",
        },
      },
      { $unwind: "$status" },
      // Group for summary
      {
        $group: {
          _id: "$user._id",
          name: { $first: "$user.fullName" },
          department: { $first: "$team.name" },
          designation: { $first: "$designation.name" },
          totalTasks: { $sum: 1 },
          completedTasks: {
            $sum: {
              $cond: [{ $eq: ["$status.name", "Completed"] }, 1, 0],
            },
          },
          pendingTasks: {
            $sum: {
              $cond: [{ $eq: ["$status.name", "In Progress"] }, 1, 0],
            },
          },
          notStartedTasks: {
            $sum: {
              $cond: [{ $eq: ["$status.name", "Not Started"] }, 1, 0],
            },
          },
          discardedTasks: {
            $sum: {
              $cond: [{ $eq: ["$status.name", "Discarded"] }, 1, 0],
            },
          },
          overdueTasks: {
            $sum: {
              $cond: [
                {
                  $and: [
                    { $eq: ["$status.name", "In Progress"] },
                    { $lt: ["$targetdate", new Date()] },
                  ],
                },
                1,
                0,
              ],
            },
          },
        },
      },
    ]);

    return tasksWithDetails;
  };

  static getMyTask = async (user_id) => {
    try {
      const userIdStr = user_id.toString();

      const tasksWithDetails = await TaskModal.aggregate([
        {
          $match: {
            isDeleted: false,
            $or: [{ assignto: userIdStr }],
          },
        },
        {
          $addFields: {
            statusObjectId: { $toObjectId: "$Taskstatus" },
            assigntoObjectId: { $toObjectId: "$assignto" },
          },
        },
        {
          $lookup: {
            from: "taskstatuses",
            localField: "statusObjectId",
            foreignField: "_id",
            as: "statusInfo",
          },
        },
        { $unwind: "$statusInfo" },
        {
          $lookup: {
            from: "users",
            localField: "assigntoObjectId",
            foreignField: "_id",
            as: "userInfo",
          },
        },
        { $unwind: "$userInfo" },
        {
          $project: {
            _id: 1,
            taskid: 1,
            name: 1,
            details: 1,
            active: 1,
            status: "$statusInfo.name",
            assignto: "$userInfo.fullName",
            createdDate: 1,
            targetdate: 1,
            priority: 1,
          },
        },
        {
          $sort: {
            _id: -1,
          },
        },
      ]);

      return tasksWithDetails;
    } catch (err) {
      console.error("Error in getMyTask:", err);
      return [];
    }
  };

  static getTaskByAssignId = async (userId) => {
    const tasksWithDetails = await TaskModal.aggregate([
      {
        $match: {
          $and: [
            {
              $or: [{ assignto: userId }, { createdby: userId }],
            },
            { isDeleted: false },
          ],
        },
      },
      {
        $addFields: {
          statusObjectId: { $toObjectId: "$Taskstatus" },
          assigntoObjectId: { $toObjectId: "$assignto" },
          createdByObjectId: { $toObjectId: "$createdby" }, // Convert string status to ObjectId
        },
      },
      {
        $lookup: {
          from: "taskstatuses",
          localField: "statusObjectId", // Use the converted statusObjectId
          foreignField: "_id",
          as: "statusInfo",
        },
      },
      {
        $unwind: "$statusInfo",
      },
      {
        $lookup: {
          from: "users",
          localField: "assigntoObjectId",
          foreignField: "_id",
          as: "userInfo",
        },
      },
      {
        $unwind: "$userInfo",
      },
      {
        $lookup: {
          from: "users",
          localField: "createdByObjectId",
          foreignField: "_id",
          as: "createdByInfo",
        },
      },
      { $unwind: "$createdByInfo" },
      {
        $project: {
          _id: 1,
          taskid: 1,
          name: 1,
          details: 1,
          active: 1,
          status: "$statusInfo.name",
          assignto: "$userInfo.fullName",
          createdby: "$createdByInfo.fullName", // Get full name of creator
          createdDate: 1,
          targetdate: 1,
          priority: 1,
        },
      },
      {
        $sort: {
          _id: -1,
        },
      },
    ]);

    return tasksWithDetails;
  };

  static getSingleTask = async (id) => {
    console.log("id------------", id);
    const taskId = new mongoose.Types.ObjectId(id);

    const tasksWithDetails = await TaskModal.aggregate([
      {
        $match: {
          _id: taskId,
          isDeleted: false,
        },
      },
      {
        $addFields: {
          taskStatusObjId: { $toObjectId: "$Taskstatus" },
          assigntoObjId: { $toObjectId: "$assignto" },
          createdByObjId: { $toObjectId: "$createdby" }, // fix here: convert createdby string to ObjectId
        },
      },
      {
        $lookup: {
          from: "taskstatuses",
          localField: "taskStatusObjId",
          foreignField: "_id",
          as: "statusInfo",
        },
      },
      { $unwind: { path: "$statusInfo", preserveNullAndEmptyArrays: true } },
      {
        $lookup: {
          from: "users",
          localField: "assigntoObjId",
          foreignField: "_id",
          as: "userInfo",
        },
      },
      { $unwind: { path: "$userInfo", preserveNullAndEmptyArrays: true } },
      {
        $lookup: {
          from: "users",
          localField: "createdByObjId",
          foreignField: "_id",
          as: "creatorInfo",
        },
      },
      { $unwind: { path: "$creatorInfo", preserveNullAndEmptyArrays: true } },
      {
        $project: {
          _id: 1,
          taskid: 1,
          name: 1,
          details: 1,
          targetdate: 1,
          createdDate: 1,
          active: 1,
          isOpenFirstTime: 1,
          isOpenFirstTimeDate: 1,
          status: "$statusInfo.name",
          assignto: "$userInfo.fullName",
          statusId: "$statusInfo._id",
          assigntoId: "$userInfo._id",
          createdBy: "$creatorInfo.fullName",
          createdById: "$creatorInfo._id",
          priority: 1,
        },
      },
    ]);

    // console.log("tasksWithDetails------------", tasksWithDetails);
    return tasksWithDetails || null;
  };

  static DeleteTask = async (id, userId) => {
    const taskId = new mongoose.Types.ObjectId(id);
    const task = await TaskModal.findByIdAndUpdate(
      taskId,
      { isActive: false, deletedBy: userId, isDeleted: true },
      { new: true }
    );
    return task;
  };

  static editTaskById = async (data) => {
  console.log("Updating task", data.id);

  const COMPLETED_STATUS_ID = '684bc6e93c9d30e5d63e35c0'; // Replace with your actual "Completed" status ID

  // 1. Fetch existing task
  const existingTask = await TaskModal.findOne({ taskid: data.id });
  if (!existingTask) throw new Error("Task not found");

  const oldAssignee = existingTask.assignto;
  const newAssignee = data.assigntoId;
  const taskCreator = existingTask.createdby;

  const assigneeChanged = oldAssignee !== newAssignee;

  // 2. Update the task
  const updatedTask = await TaskModal.findOneAndUpdate(
    { taskid: data.id },
    {
      details: data.details,
      assignto: newAssignee,
      Taskstatus: data.statusId,
      remarks: data.remarks,
      updatedDate: Date.now(),
      updatedBy: data.updatedBy,
      priority: data.priority,
    },
    { new: true }
  );

  // 3. If assignee changed → Log + Notify new assignee
  if (assigneeChanged) {
    const datas = await TaskLogsModal.create({
      taskid: existingTask._id,
      description: `Task assigned to a new user.`,
      performedBy: data.updatedBy,
      actions: "Updated",
    });

    datas.save();

    console.log(datas, "Task log created for reassignment");



    await NotificationModal.create({
      recieverId: newAssignee,
      senderId: data.updatedBy,
      taskId: updatedTask._id,
      message: `You have been assigned a new task: ${updatedTask.name}`,
    });
  }

  // 4. If task marked as completed → Notify task creator
  if (data.statusId === COMPLETED_STATUS_ID) {
    try {
      console.log("Task marked as completed, fetching task creator...");
      await TaskLogsModal.create({
        taskid: existingTask._id,
        description: `Task marked as completed.`,
        performedBy: data.updatedBy,
        actions: "Status Changed",
      });
    } catch (error) {
      console.log("Error fetching task creator:", error.message);
      
    }

    await NotificationModal.create({
      recieverId: taskCreator,
      senderId: data.updatedBy,
      taskId: updatedTask._id,
      message: `The task "${updatedTask.name}" assigned by you has been completed.`,
    });
  }

  return updatedTask;
};



  static reAssignTask = async (taskId, AssignToId, userId) => {
    try {
      const TaskId = new mongoose.Types.ObjectId(taskId);
      const task = await TaskModal.findByIdAndUpdate(
        TaskId,
        {
          updatedDate: Date.now(),
          assignto: AssignToId,
          updatedBy: userId,
        },
        { new: true }
      );
      console.log("Soft Deleted Task:", task);
      return task;
    } catch (err) {
      return err;
    }
  };

  // static reAssignTask = async (taskId, AssignToId, userId) => {
  //   try {
  //     const TaskId = new mongoose.Types.ObjectId(taskId);
  //     const task = await TaskModal.findByIdAndUpdate(
  //       TaskId,
  //       {
  //         updatedDate: Date.now(),
  //         assignto: AssignToId,
  //         updatedBy: userId,
  //       },
  //       { new: true }
  //     );
  //     console.log("Soft Deleted Task:", task);
  //     return task;
  //   } catch (err) {
  //     return err;
  //   }
  // };

  static changeTaskStatus = async (taskId, taskStatusId, UserId) => {
    try {
      const TaskId = new mongoose.Types.ObjectId(taskId);
      const task = await TaskModal.findByIdAndUpdate(
        TaskId,
        {
          updatedDate: Date.now(),
          Taskstatus: taskStatusId,
          updatedBy: UserId,
        },
        { new: true }
      );
      // Log the status change
      const taskLog = await TaskLogsModal.create({
        taskid: TaskId,
        actions: "Status Changed", // enum value
        description: `Task status changed `,
        performedBy: UserId,
        performedDate: new Date(), // current date
      });
      console.log("Task Log Created:", taskLog);
      console.log("Soft Deleted Task:", task);
      return task;
    } catch (err) {
      return err;
    }
  };

  static TaskCount = async () => {
    const taskCount = await TaskModal.countDocuments();
    console.log("taskCount-------------", taskCount);
    return taskCount;
  };

  static NotesCount = async () => {
    const taskCount = await TaskNotesModal.countDocuments();
    console.log("taskCount-------------", taskCount);
    return taskCount;
  };

  static TaskStatusWise = async () => {
    const task = await TaskModal.aggregate([
      {
        $lookup: {
          from: "taskstatuses", // 👈 Name of the status collection
          localField: "status", // 👈 Field in the tasks collection
          foreignField: "_id", // 👈 Field in the taskstatus collection
          as: "statusDetails",
        },
      },
      {
        $unwind: "$statusDetails",
      },
      {
        $group: {
          _id: "$statusDetails.name", // 👈 Grouping by status name
          tasks: {
            $push: {
              _id: "$_id",
              taskid: "$taskid",
              name: "$name",
              details: "$details",
              targetdate: "$targetdate",
              assignto: "$assignto",
              active: "$active",
              assigndate: "$assigndate",
            },
          },
          count: { $sum: 1 },
        },
      },
    ]);

    return task;
  };

  static TaskStatusWiseCount = async () => {
    const taskCounts = await TaskModal.aggregate([
      {
        $match: { isDeleted: false },
      },
      {
        $lookup: {
          from: "taskstatuses",
          let: { taskStatusId: "$Taskstatus" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $eq: [
                    "$_id",
                    {
                      $cond: [
                        { $eq: [{ $type: "$$taskStatusId" }, "string"] },
                        { $toObjectId: "$$taskStatusId" },
                        "$$taskStatusId",
                      ],
                    },
                  ],
                },
              },
            },
            { $project: { name: 1 } },
          ],
          as: "statusDetails",
        },
      },
      { $unwind: "$statusDetails" },
      {
        $group: {
          _id: "$statusDetails.name",
          count: { $sum: 1 },
        },
      },
      {
        $project: {
          _id: 0,
          name: "$_id",
          count: 1,
        },
      },
      { $sort: { name: 1 } },
    ]);

    return taskCounts;
  };

  static TaskStatusWiseCountforUser = async (userId) => {
    const taskCounts = await TaskModal.aggregate([
      {
        $match: {
          isDeleted: false,
          $or: [{ createdby: userId }, { assignto: userId }],
        },
      },
      {
        $lookup: {
          from: "taskstatuses",
          let: { taskStatusId: "$Taskstatus" },
          pipeline: [
            {
              $match: {
                $expr: {
                  $eq: [
                    "$_id",
                    {
                      $cond: [
                        { $eq: [{ $type: "$$taskStatusId" }, "string"] },
                        { $toObjectId: "$$taskStatusId" },
                        "$$taskStatusId",
                      ],
                    },
                  ],
                },
              },
            },
            { $project: { name: 1 } },
          ],
          as: "statusDetails",
        },
      },
      { $unwind: "$statusDetails" },
      {
        $group: {
          _id: "$statusDetails.name",
          count: { $sum: 1 },
        },
      },
      {
        $project: {
          _id: 0,
          name: "$_id",
          count: 1,
        },
      },
      { $sort: { name: 1 } },
    ]);

    return taskCounts;
  };

  static AddNotes = async (data) => {
    console.log("data in add notes-----------", data);

    try {
      const task = await new TaskNotesModal({
        taskid: data.taskid,
        notesId: data.notesId,
        notes: data.notes,
        addedBy: data.addedBy,
      });

      // Log the note addition
      const taskLog = await TaskLogsModal.create({
        taskid: task.taskid,
        actions: "Updated", // enum value
        description: `Note added to task`,
        performedBy: data.addedBy,
        performedDate: new Date(), // current date
      });
      await task.save();
      return task;
    } catch (err) {
      return err;
    }
  };

  static getNotes = async (taskId) => {
    try {
      const task = await TaskNotesModal.aggregate([
        {
          $match: {
            taskid: taskId, // taskId is a string
          },
        },
        {
          $addFields: {
            taskObjId: { $toObjectId: "$taskid" },
            addedByObjId: { $toObjectId: "$addedBy" },
          },
        },
        {
          $lookup: {
            from: "tasks",
            localField: "taskObjId",
            foreignField: "_id",
            as: "taskDetails",
          },
        },
        {
          $unwind: {
            path: "$taskDetails",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "users",
            localField: "addedByObjId",
            foreignField: "_id",
            as: "userDetails",
          },
        },
        {
          $unwind: {
            path: "$userDetails",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            _id: 1,
            notesId: 1,
            notes: 1,
            addedDate: 1,
            updatedDate: 1,
            active: 1,
            userName: "$userDetails.fullName",
            taskName: "$taskDetails.name",
          },
        },
      ]);

      return task;
    } catch (err) {
      console.error(err);
      return err;
    }
  };

  static FirstTimeOpenRepo = async (taskId) => {
    const TaskObjId = new mongoose.Types.ObjectId(taskId);
    console.log("task id----------", taskId);

    try {
      // const CurrentDAte=await SaveCurrentDateAndTime();
      const task = await TaskModal.findOneAndUpdate(
        {
          _id: TaskObjId,
          isOpenFirstTime: { $ne: true }, // Only update if it's not true
        },
        {
          $set: {
            isOpenFirstTime: true,
            isOpenFirstTimeDate: Date.now(),
            Taskstatus: "684bc72e3c9d30e5d63e35c2", // status set "IN PROGRESS"
          },
        },
        { new: true }
      );

      return task; // will be null if no update was made (because condition wasn't met)
    } catch (err) {
      return err;
    }
  };

  static getCurrentNotesOfTask = async (taskId) => {
    console.log("task id----------", taskId);

    try {
      const task = await TaskNotesModal.findOne({ taskid: taskId })
        .sort({ addedDate: -1 }) // Sort by newest addedDate
        .exec();

      return task; // will be null if no notes found
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  static getMyTaskCount = async (user_id) => {
    try {
      const userIdStr = user_id.toString();

      const tasksWithDetails = await TaskModal.aggregate([
        {
          $match: {
            isDeleted: false,
            assignto: userIdStr, // ✅ Include only tasks assigned to current user
          },
        },
        {
          $addFields: {
            statusObjectId: { $toObjectId: "$Taskstatus" },
            assigntoObjectId: { $toObjectId: "$assignto" },
          },
        },
        {
          $lookup: {
            from: "taskstatuses",
            localField: "statusObjectId",
            foreignField: "_id",
            as: "statusInfo",
          },
        },
        { $unwind: "$statusInfo" },
        {
          $lookup: {
            from: "users",
            localField: "assigntoObjectId",
            foreignField: "_id",
            as: "userInfo",
          },
        },
        { $unwind: "$userInfo" },
        {
          $project: {
            _id: 1,
            taskid: 1,
            name: 1,
            details: 1,
            active: 1,
            status: "$statusInfo.name",
            assignto: "$userInfo.fullName",
            createdDate: 1,
            targetdate: 1,
            priority: 1, // Include priority if needed
          },
        },
        {
          $sort: {
            _id: -1,
          },
        },
      ]);
      // console.log("Tasks with details: of my task", tasksWithDetails);
      return tasksWithDetails;
    } catch (err) {
      console.error("Error in getMyTask:", err);
      return [];
    }
  }; // user Task count for admin and user

  static getAllTaskCount = async (user_id) => {
    try {
      const userIdStr = user_id.toString();

      const tasksWithDetails = await TaskModal.aggregate([
        {
          $match: {
            isDeleted: false,
            assignto: { $ne: userIdStr }, // ✅ Exclude current user
          },
        },
        {
          $addFields: {
            statusObjectId: { $toObjectId: "$Taskstatus" },
            assigntoObjectId: { $toObjectId: "$assignto" },
          },
        },
        {
          $lookup: {
            from: "taskstatuses",
            localField: "statusObjectId",
            foreignField: "_id",
            as: "statusInfo",
          },
        },
        { $unwind: "$statusInfo" },
        {
          $lookup: {
            from: "users",
            localField: "assigntoObjectId",
            foreignField: "_id",
            as: "userInfo",
          },
        },
        { $unwind: "$userInfo" },
        {
          $project: {
            _id: 1,
            taskid: 1,
            name: 1,
            details: 1,
            active: 1,
            status: "$statusInfo.name",
            assignto: "$userInfo.fullName",
            createdDate: 1,
            targetdate: 1,
          },
        },
        {
          $sort: {
            _id: -1,
          },
        },
      ]);

      return tasksWithDetails;
    } catch (err) {
      console.error("Error in getAllTaskCount:", err);
      return [];
    }
  }; // Admin task count  not in use becoz usecase is not there

  static getTeamTask = async (userId, userType) => {
    try {
      if (!userId) throw new Error("userId is required");

      // Step 1: Get user's department (i.e., team ID)
      const currentUser = await UserModel.findById(userId)
        .select("department")
        .lean();
      if (!currentUser || !currentUser.department)
        throw new Error("User's team/department not found");

      const userTeam = currentUser.department;
      // console.log("User's team/department:", userTeam);

      // Step 2: Get all users in that department
      const teamUsers = await UserModel.find({ department: userTeam })
        .select("_id reportingto assignedTo")
        .lean();
      console.log("Users in team:", teamUsers);
      // Step 3: Get list of user IDs reporting to or assigned to me
      const filteredUserIds = teamUsers
        .filter(
          (u) =>
            u.reportingto?.toString() === userId.toString() ||
            u.assignedTo?.toString() === userId.toString()
        )
        .map((u) => u._id);
      console.log("Filtered User IDs:", filteredUserIds);

      if (filteredUserIds.length === 0) return [];

      // Step 4: Aggregation pipeline
      const tasks = await TaskModal.aggregate([
        {
          $match: {
            isDeleted: false,
            assignto: { $in: filteredUserIds.map((id) => id.toString()) },
          },
        },
        {
          $addFields: {
            assigneeObjectId: { $toObjectId: "$assignto" },
            taskstatusObjectId: { $toObjectId: "$Taskstatus" },
          },
        },
        {
          $lookup: {
            from: "users",
            localField: "assigneeObjectId",
            foreignField: "_id",
            as: "assignee",
          },
        },
        { $unwind: "$assignee" },
        {
          $lookup: {
            from: "taskstatuses",
            localField: "taskstatusObjectId",
            foreignField: "_id",
            as: "statusInfo",
          },
        },
        { $unwind: "$statusInfo" },
        {
          $project: {
            _id: 1,
            taskid: 1,
            name: 1,
            details: 1,
            targetdate: 1,
            createdDate: 1,
            assignto: "$assignee.fullName",
            status: "$statusInfo.name",
            priority: 1,
          },
        },
      ]);
      // console.log("Tasks for team:", tasks);
      return tasks;
    } catch (error) {
      console.error("Error in getTeamTask:", error);
      return [];
    }
  };

  static getTaskLogs = async (taskid) => {
  try {
    if (!taskid) throw new Error("taskid is required");

    const taskLogs = await TaskLogsModal.aggregate([
      {
        $match: { taskid: taskid },
      },
      {
        $sort: { performedDate: -1 },
      },
      {
        $addFields: {
          performedByObjectId: { $toObjectId: "$performedBy" }, // 👈 convert string to ObjectId
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "performedByObjectId",
          foreignField: "_id",
          as: "userDetails",
        },
      },
      {
        $unwind: {
          path: "$userDetails",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $project: {
          _id: 1,
          taskid: 1,
          description: 1,
          action: "$actions",
          performedDate: 1,
          performedBy: "$userDetails.fullName", // ✅ show user's name
        },
      },
    ]);

    return taskLogs;

  } catch (error) {
    console.error("Error in getTaskLogs:", error);
    throw new Error("Error fetching task logs: " + error.message);
  }
};
}

module.exports = taskRepositiories;
