const mongoose = require("mongoose");
const { stringToDate } = require("../../utils/service");
const { TeamModel, DesignationModel, TeamMemberModel } = require("../../model/User/teamModal");
const { Types } = require("mongoose");
const { UserModel } = require("../../model/User/userModel");

class teamRepositiories {
  static CreateTeam=async({name,createdBy})=>{
     const AddTeam=new TeamModel({
      name: name,
      createdBy: createdBy,}); // Assuming userid is the ID of the user creating the team});
      console.log("AddTeam",AddTeam);
     await AddTeam.save() 
     return AddTeam;
  }

  static CreateDesignation=async({name,createdBy})=>{
    const AddTeam=new DesignationModel({
      name: name,
      createdBy: createdBy,});
    await AddTeam.save() 
    return AddTeam;
 }

 static getDesignation=async()=>{
    const result = await DesignationModel.find(
        { isActive: true },          // Filter
        { _id: 1, id: 1, name: 1 }   // Projection: include `id` and `name`, exclude `_id`
      );
      return result;
 }

 static getTeam=async()=>{
    const result = await TeamModel.find(
        { isActive: true },          // Filter
        { _id: 1, id: 1, name: 1 }   // Projection: include `id` and `name`, exclude `_id`
      );
      return result;
 }

 static deleteTeam=async(id)=>{
  try{
  const teamid = new Types.ObjectId(id);
  const result = await TeamModel.findByIdAndUpdate(teamid,{isActive:false},{new:true})
    return result;
  }
  catch(err){
    return err;
  }
}


 static addTeamMember=async(Teamdata)=>{
   console.log("repodata fdata---------",Teamdata);
   try{
   const result =  new TeamMemberModel(Teamdata);
   await result.save();
     return result;
   }
   catch(error)
   {
      console.log(error);
      throw error;
   }
}

static getTeamMember=async()=>{
   try{
    const result = await TeamMemberModel.aggregate([
      // Convert userid and departmentid strings to ObjectId
      {
        $addFields: {
          userObjectId: { $toObjectId: "$userid" },
          teamObjectId: { $toObjectId: "$departmentid" },
        },
      },
    
      // Lookup user info
      {
        $lookup: {
          from: "users",
          localField: "userObjectId",
          foreignField: "_id",
          as: "userInfo",
        },
      },
      { $unwind: { path: "$userInfo", preserveNullAndEmptyArrays: true } },
    
      // Lookup team info
      {
        $lookup: {
          from: "teams",
          localField: "teamObjectId",
          foreignField: "_id",
          as: "teamInfo",
        },
      },
      { $unwind: { path: "$teamInfo", preserveNullAndEmptyArrays: true } },
    
      // Project required fields
      {
        $project: {
          _id: 1,
          userid: 1,
          departmentid: 1,
          userName: "$userInfo.fullName",
          userEmail: "$userInfo.email",
          departmentName: "$teamInfo.name",
        },
      },
    ]);
    
       
     return result;
   }
   catch(error)
   {
      console.log(error);
      throw error;
   }
}

static getTeamWiseMember=async(id)=>{
  try{
    const result = await TeamMemberModel.aggregate([
      {
        $match: {
          departmentid: id, // still string match since `departmentid` is string
        },
      },
      // Convert userid string to ObjectId
      {
        $addFields: {
          userObjectId: { $toObjectId: "$userid" },
        },
      },
      // Lookup user details
      {
        $lookup: {
          from: "users",
          localField: "userObjectId",
          foreignField: "_id",
          as: "userInfo",
        },
      },
      {
        $unwind: {
          path: "$userInfo",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $match: {
          "userInfo.isActive": true, // Filter to include only active users 
          }
      },
      // Convert departmentid string to ObjectId
      {
        $addFields: {
          departmentObjectId: { $toObjectId: "$departmentid" },
        },
      },
      // Lookup department (team) details
      {
        $lookup: {
          from: "teams",
          localField: "departmentObjectId",
          foreignField: "_id",
          as: "teamInfo",
        },
      },
      {
        $unwind: {
          path: "$teamInfo",
          preserveNullAndEmptyArrays: true,
        },
      },
      // Final projection
      {
        $project: {
          _id: 0,
          userId: "$userid",
          userName: "$userInfo.fullName",
          departmentId: "$departmentid",
          departmentName: "$teamInfo.name",
        },
      },
    ]);
    
    return result;
  }
  catch(error)
  {
     console.log(error);
     throw error;
  }
}


static getTeamWiseUserById = async (deptId) => {
  try {
    const result = await UserModel.aggregate([
      {
        $match: {
          department: deptId // this is a string
        }
      },
      {
        $addFields: {
          deptObjectId: { $toObjectId: "$department" },
          desgObjectId: { $toObjectId: "$designation" },
          reportingToObjId: { $toObjectId: "$reportingto" }
        }
      },
      {
        $lookup: {
          from: "teams",
          localField: "deptObjectId",
          foreignField: "_id",
          as: "departmentInfo"
        }
      },
      {
        $unwind: {
          path: "$departmentInfo",
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $lookup: {
          from: "designations",
          localField: "desgObjectId",
          foreignField: "_id",
          as: "designationInfo"
        }
      },
      {
        $unwind: {
          path: "$designationInfo",
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $lookup: {
          from: "users", // Assuming your UserModel collection name is "users"
          localField: "reportingToObjId",
          foreignField: "_id",
          as: "reportingToUser"
        }
      },
      {
        $unwind: {
          path: "$reportingToUser",
          preserveNullAndEmptyArrays: true
        }
      },
      {
        $match: {
          isActive: true // Filter to include only active users
        }
      },
      {
        $project: {
          fullName: 1,
          email: 1,
          mobile: 1,
          designation: 1,
          reportingto: 1,
          isActive: 1,
          addedDate: 1,
          departmentName: "$departmentInfo.name",
          designationName: "$designationInfo.name",
          reportingToName: "$reportingToUser.fullName"

        }
      }
    ]);

    return result;
  } catch (error) {
    console.error("Error in getTeamWiseUserById:", error);
    throw error;
  }
};

}

module.exports = teamRepositiories;
