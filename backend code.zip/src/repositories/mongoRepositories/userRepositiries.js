const {
  UserModel,
  UserRoleModel,
  RoleModel,
} = require("../../model/User/userModel");
const {
  LoginAutditModel,
  LoginUserModel,
} = require("../../model/Auth/authModel");
const mongoose = require("mongoose");
const { Types } = require("mongoose");
const { TeamMemberModel } = require("../../model/User/teamModal");
const { TaskModal } = require("../../model/User/taskModel");

class UserRepositoryMongo {
  static findeUserByEmail = async (email) => {
    try {
      const user = await UserModel.findOne({ email });
      return user;
    } catch (err) {
      return err;
    }
  };

  static getRoleId = async (name) => {
    try {
      const role = await RoleModel.findOne(
        { name: { $regex: `^${name}$`, $options: "i" } },
        { _id: 1 } // Only return _id field
      );
      return role?._id || null;
    } catch (err) {
      return err;
    }
  };

  static findRoleByName = async (name) => {
    try {
      const role = await RoleModel.findOne({
        name: { $regex: `^${name}$`, $options: "i" },
      });
      return role;
    } catch (err) {
      return err;
    }
  };

  static InsertUserData = async (UserData) => {
    try {
      const user = new UserModel(UserData);
      await user.save();
      return user;
    } catch (err) {
      return err;
    }
  };

  static addUserInDashboard = async (UserData) => {
    // console.log("repodata fdata---------", UserData);
    try {
      const result = new UserModel(UserData);
      await result.save();
      return result;
    } catch (error) {
      console.log(error);
      throw error;
    }
  };

  static DeleteUser = async (id, user_id) => {
    try {
      const userObjectId = new Types.ObjectId(id); // Convert to ObjectId

      const updatedUser = await UserModel.findByIdAndUpdate(
        userObjectId,
        {
          isDeleted: true,
          isActive: false,
          deletedby: user_id,
          deletedDate: new Date(),
        },
        { new: true }
      );

      return updatedUser;
    } catch (err) {
      console.error("Error deleting user:", err);
      return err;
    }
  };

  static updatedUser = async (userId, user) => {
    try {
      const userObjectId = new Types.ObjectId(userId);

      const updatedUser = await UserModel.findByIdAndUpdate(
        userObjectId,
        {
          fullName: user.name,
          email: user.email,
          mobile: user.mobile,
          department: user.department,
          designation: user.designation,
          reportingto: user.reportingto,
          updatedby: userId,
          updatedDate: new Date(),
          departmentmain: user.departmentmain, // Ensure this field is updated
        },
        { new: true } // Return the updated document
      );
      // console.log("Updated User:", updatedUser);
      return updatedUser;
    } catch (err) {
      console.error("Error updating user:", err);
      throw err; // Consider throwing instead of returning the error
    }
  };

  static UpdatePassword = async (userId, password) => {
    try {
      const userObjectId = new mongoose.Types.ObjectId(userId);

      const updatedUser = await UserModel.findByIdAndUpdate(
        userObjectId,
        {
          password: password,
          updatedby: userId,
          updatedDate: new Date(),
        },
        { new: true } // Return the updated document
      );

      return updatedUser;
    } catch (err) {
      console.error("Error updating user:", err);
      throw err; // Consider throwing instead of returning the error
    }
  };

  static InsertLoginAuditData = async (UserData) => {
    console.log(UserData, "sdfsdfsfsd------------");
    try {
      const LoginAudit = new LoginAutditModel(UserData);
      await LoginAudit.save();
      return LoginAudit;
    } catch (err) {
      return err;
    }
  };

  static InsertLoginUser = async (UserData) => {
    try {
      const LoginUser = new LoginUserModel(UserData);
      await LoginUser.save();
      return LoginUser;
    } catch (err) {
      return err;
    }
  };
  static InsertUserRole = async (UserData) => {
    console.log(UserData, "InsertLoginUser------------");
    try {
      const UserRole = new UserRoleModel(UserData);
      await UserRole.save();
      return UserRole;
    } catch (err) {
      return err;
    }
  };
  static InsertRole = async (UserData) => {
    console.log(UserData, "InsertLoginUser------------");
    try {
      const Role = new RoleModel(UserData);
      await Role.save();
      return Role;
    } catch (err) {
      return err;
    }
  };

  static getRoleByUserId = async (userId) => {
    try {
      const result = await UserRoleModel.aggregate([
        {
          $match: {
            userId: userId,
          },
        },
        {
          $lookup: {
            from: "roles", // 👈 MongoDB collection name (must be lowercase & plural usually)
            localField: "roleId", // 👈 Field in userroles
            foreignField: "_id", // 👈 Field in roles
            as: "roleInfo", // 👈 New array field with matched role data
          },
        },
        {
          $unwind: "$roleInfo", // 👈 Optional: if you want to flatten the array
        },
        {
          $project: {
            role: "$roleInfo.name", // 👈 Only show role name from joined collection
          },
        },
      ]);
      return result;
    } catch (err) {
      return err;
    }
  };

static getAllUsers = async ({ search, userId, userRole }) => {
  try {
    const isSuperAdmin = userRole?.toLowerCase() === "superadmin";
    const objectUserId = new Types.ObjectId(userId);

    const matchStage = {
      isDeleted: false,
    };

    if (!isSuperAdmin) {
      matchStage.$or = [
        { relatedUser: objectUserId },
        { assignedTo: objectUserId },
        { reportingto: objectUserId.toString() },
      ];
    }

    const pipeline = [
      { $match: {
        isDeleted: false,
      } },

      {
        $addFields: {
          designationObjectId: {
            $cond: [
              {
                $and: [
                  { $eq: [{ $type: "$designation" }, "string"] },
                  { $regexMatch: { input: "$designation", regex: /^[0-9a-fA-F]{24}$/ } },
                ],
              },
              { $toObjectId: "$designation" },
              "$designation",
            ],
          },
          departmentObjectId: {
            $cond: [
              {
                $and: [
                  { $eq: [{ $type: "$department" }, "string"] },
                  { $regexMatch: { input: "$department", regex: /^[0-9a-fA-F]{24}$/ } },
                ],
              },
              { $toObjectId: "$department" },
              "$department",
            ],
          },
          departmentMainObjectId: {
            $cond: [
              {
                $and: [
                  { $eq: [{ $type: "$departmentmain" }, "string"] },
                  { $regexMatch: { input: "$departmentmain", regex: /^[0-9a-fA-F]{24}$/ } },
                ],
              },
              { $toObjectId: "$departmentmain" },
              "$departmentmain",
            ],
          },
          userTypeObjectId: {
            $cond: [
              {
                $and: [
                  { $eq: [{ $type: "$userType" }, "string"] },
                  { $regexMatch: { input: "$userType", regex: /^[0-9a-fA-F]{24}$/ } },
                ],
              },
              { $toObjectId: "$userType" },
              "$userType",
            ],
          },
          reportingToObjectId: {
            $cond: [
              {
                $and: [
                  { $eq: [{ $type: "$reportingto" }, "string"] },
                  { $regexMatch: { input: "$reportingto", regex: /^[0-9a-fA-F]{24}$/ } },
                ],
              },
              { $toObjectId: "$reportingto" },
              "$reportingto",
            ],
          },
          assignedToObjectId: {
            $cond: [
              {
                $and: [
                  { $eq: [{ $type: "$assignedTo" }, "string"] },
                  { $regexMatch: { input: "$assignedTo", regex: /^[0-9a-fA-F]{24}$/ } },
                ],
              },
              { $toObjectId: "$assignedTo" },
              "$assignedTo",
            ],
          },
        },
      },

      {
        $lookup: {
          from: "roles",
          localField: "userTypeObjectId",
          foreignField: "_id",
          as: "roleInfo",
        },
      },
      {
        $unwind: {
          path: "$roleInfo",
          preserveNullAndEmptyArrays: false,
        },
      },
      {
        $match: {
          "roleInfo.isSuperAdmin": { $ne: true },
        },
      },
      {
        $lookup: {
          from: "designations",
          localField: "designationObjectId",
          foreignField: "_id",
          as: "designationInfo",
        },
      },
      {
        $unwind: {
          path: "$designationInfo",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "teams",
          localField: "departmentObjectId",
          foreignField: "_id",
          as: "teamInfo",
        },
      },
      {
        $unwind: {
          path: "$teamInfo",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "departments",
          localField: "departmentMainObjectId",
          foreignField: "_id",
          as: "departmentMainInfo",
        },
      },
      {
        $unwind: {
          path: "$departmentMainInfo",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "reportingToObjectId",
          foreignField: "_id",
          as: "reportingUserInfo",
        },
      },
      {
        $unwind: {
          path: "$reportingUserInfo",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "assignedToObjectId",
          foreignField: "_id",
          as: "assignedToInfo",
        },
      },
      {
        $unwind: {
          path: "$assignedToInfo",
          preserveNullAndEmptyArrays: true,
        },
      },
    ];

    if (search && search.trim() !== "") {
      const searchRegex = new RegExp(search.trim(), "i");
      pipeline.push({
        $match: {
          $or: [
            { fullName: { $regex: searchRegex } },
            { email: { $regex: searchRegex } },
            { mobile: { $regex: searchRegex } },
            { "designationInfo.name": { $regex: searchRegex } },
            { "teamInfo.name": { $regex: searchRegex } },
            { "departmentMainInfo.name": { $regex: searchRegex } },
            { "reportingUserInfo.fullName": { $regex: searchRegex } },
            { "assignedToInfo.fullName": { $regex: searchRegex } },
          ],
        },
      });
    }

    pipeline.push({
      $project: {
        _id: 0,
        userId: "$_id",
        username: "$fullName",
        email: "$email",
        mobile: { $ifNull: ["$mobile", "N/A"] },
        addeddate: "$addedDate",
        designation: { $ifNull: ["$designationInfo.name", "N/A"] },
        department: { $ifNull: ["$teamInfo.name", "N/A"] },
        departmentMain: { $ifNull: ["$departmentMainInfo.name", "N/A"] },
        reportingTo: { $ifNull: ["$reportingUserInfo.fullName", "N/A"] },
        reportingToId: { $ifNull: ["$reportingto", "N/A"] },
        assignedTo: { $ifNull: ["$assignedToInfo.fullName", "N/A"] },
        assignedToId: { $ifNull: ["$assignedTo", "N/A"] },
        designationId: { $ifNull: ["$designation", "N/A"] },
        departmentId: { $ifNull: ["$department", "N/A"] },
        departmentMainId: { $ifNull: ["$departmentmain", "N/A"] },
        userTypeId: { $ifNull: ["$userType", "N/A"] },
        userType: { $ifNull: ["$roleInfo.name", "N/A"] },
        isActive: { $ifNull: ["$isActive", true] },
      },
    });

    pipeline.push({ $sort: { addeddate: -1 } });

    const result = await UserModel.aggregate(pipeline);
    return result;
  } catch (err) {
    console.error("Aggregation Error:", err);
    throw err;
  }
};



  static getUserListDropdown = async () => {
    try {
      const result = await UserModel.aggregate([
      {
        $match: {
          isDeleted: false,
          isActive: true,
        },
      },
      // Convert string fields to ObjectId
      {
        $addFields: {
          designationObjId: { $toObjectId: "$designation" },
          departmentObjId: { $toObjectId: "$departmentmain" },
        },
      },
      {
        $lookup: {
          from: "designations",
          localField: "designationObjId",
          foreignField: "_id",
          as: "designationDetails",
        },
      },
      {
        $lookup: {
          from: "departments",
          localField: "departmentObjId",
          foreignField: "_id",
          as: "departmentDetails",
        },
      },
      {
        $unwind: {
          path: "$designationDetails",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $unwind: {
          path: "$departmentDetails",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $project: {
          _id: 1,
          fullName: 1,
          designation: {
            $ifNull: ["$designationDetails.name", "N/A"],
          },
          department: {
            $ifNull: ["$departmentDetails.name", "N/A"],
          },
        },
      },
    ]); // much faster response

      return result;
    } catch (err) {
      console.error("Aggregation Error:", err);
      throw err;
    }
  }; // some changes made here to get the user list dropdown

  static getReportingUsersTasks = async (user_id) => {
    try {
      const reportingUsers = await UserModel.find({
        reportingto: user_id,
      }).select("_id");

      const reportingUserIds = reportingUsers.map((user) =>
        user._id.toString()
      );
      const allAssigneeIds = [...reportingUserIds, user_id.toString()];

      const tasksWithDetails = await TaskModal.aggregate([
        {
          $match: {
            isDeleted: false,
            assignto: { $in: allAssigneeIds },
          },
        },
        {
          $addFields: {
            statusObjectId: {
              $cond: [
                {
                  $and: [
                    { $eq: [{ $type: "$Taskstatus" }, "string"] },
                    { $eq: [{ $strLenCP: "$Taskstatus" }, 24] },
                  ],
                },
                { $toObjectId: "$Taskstatus" },
                null,
              ],
            },
            assigntoObjectId: {
              $cond: [
                {
                  $and: [
                    { $eq: [{ $type: "$assignto" }, "string"] },
                    { $eq: [{ $strLenCP: "$assignto" }, 24] },
                  ],
                },
                { $toObjectId: "$assignto" },
                null,
              ],
            },
            createdByObjectId: {
              $cond: [
                {
                  $and: [
                    { $eq: [{ $type: "$createdby" }, "string"] },
                    { $eq: [{ $strLenCP: "$createdby" }, 24] },
                  ],
                },
                { $toObjectId: "$createdby" },
                null,
              ],
            },
          },
        },
        {
          $lookup: {
            from: "taskstatuses", // collection name for TaskstatusModal
            localField: "statusObjectId",
            foreignField: "_id",
            as: "statusInfo",
          },
        },
        {
          $unwind: {
            path: "$statusInfo",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "users",
            localField: "assigntoObjectId",
            foreignField: "_id",
            as: "userInfo",
          },
        },
        {
          $unwind: {
            path: "$userInfo",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "users",
            localField: "createdByObjectId",
            foreignField: "_id",
            as: "createdByInfo",
          },
        },
        {
          $unwind: {
            path: "$createdByInfo",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            _id: 1,
            taskid: 1,
            name: 1,
            details: 1,
            active: 1,
            status: "$statusInfo.name", // this will now work!
            assignto: { $ifNull: ["$userInfo.fullName", "N/A"] },
            createdby: { $ifNull: ["$createdByInfo.fullName", "N/A"] },
            createdDate: 1,
            targetdate: 1,
          },
        },
        {
          $sort: {
            _id: -1,
          },
        },
      ]);

      return tasksWithDetails;
    } catch (err) {
      console.error("Error in getReportingUsersTasks:", err);
      return [];
    }
  };
  // this is modified

static getUserListCustom = async (userId) => {
  try {
    const objectUserId = new Types.ObjectId(userId);

    const pipeline = [
      {
        $match: {
          isDeleted: false,
          isActive: true,
        },
      },
      {
        $addFields: {
          userTypeStr: {
            $cond: [{ $eq: [{ $type: "$userType" }, "string"] }, "$userType", null],
          },
          designationStr: {
            $cond: [{ $eq: [{ $type: "$designation" }, "string"] }, "$designation", null],
          },
          departmentStr: {
            $cond: [{ $eq: [{ $type: "$department" }, "string"] }, "$department", null],
          },
          reportingToStr: {
            $cond: [{ $eq: [{ $type: "$reportingto" }, "string"] }, "$reportingto", null],
          },
        },
      },
      {
        $set: {
          userTypeObjectId: {
            $convert: {
              input: "$userTypeStr",
              to: "objectId",
              onError: null,
              onNull: null,
            },
          },
          designationObjectId: {
            $convert: {
              input: "$designationStr",
              to: "objectId",
              onError: null,
              onNull: null,
            },
          },
          departmentObjectId: {
            $convert: {
              input: "$departmentStr",
              to: "objectId",
              onError: null,
              onNull: null,
            },
          },
          reportingToObjectId: {
            $convert: {
              input: "$reportingToStr",
              to: "objectId",
              onError: null,
              onNull: null,
            },
          },
        },
      },
      {
        $lookup: {
          from: "roles",
          localField: "userTypeObjectId",
          foreignField: "_id",
          as: "roleInfo",
        },
      },
      { $unwind: { path: "$roleInfo", preserveNullAndEmptyArrays: false } },
      {
        $match: {
          "roleInfo.name": { $ne: "SuperAdmin" },
        },
      },
      {
        $lookup: {
          from: "designations",
          localField: "designationObjectId",
          foreignField: "_id",
          as: "designationInfo",
        },
      },
      { $unwind: { path: "$designationInfo", preserveNullAndEmptyArrays: true } },
      {
        $lookup: {
          from: "teams",
          localField: "departmentObjectId",
          foreignField: "_id",
          as: "teamInfo",
        },
      },
      { $unwind: { path: "$teamInfo", preserveNullAndEmptyArrays: true } },
      {
        $lookup: {
          from: "users",
          localField: "reportingToObjectId",
          foreignField: "_id",
          as: "reportingUserInfo",
        },
      },
      { $unwind: { path: "$reportingUserInfo", preserveNullAndEmptyArrays: true } },
      {
        $project: {
          _id: 0,
          userId: "$_id",
          username: "$fullName",
          email: "$email",
          mobile: { $ifNull: ["$mobile", "N/A"] },
          addeddate: "$addedDate",
          designation: { $ifNull: ["$designationInfo.name", "N/A"] },
          department: { $ifNull: ["$teamInfo.name", "N/A"] },
          reportingTo: { $ifNull: ["$reportingUserInfo.fullName", "N/A"] },
          designationId: { $ifNull: ["$designation", "N/A"] },
          departmentId: { $ifNull: ["$department", "N/A"] },
          reportingToId: { $ifNull: ["$reportingto", "N/A"] },
          userTypeId: { $ifNull: ["$userType", "N/A"] },
          userType: { $ifNull: ["$roleInfo.name", "N/A"] },
        },
      },
    ];

    const result = await UserModel.aggregate(pipeline);
    return result;
  } catch (error) {
    console.error("Error in getUserListCustom:", error);
    throw error;
  }
};


  static getLoginUser = async (email) => {
    try {
      const result = await UserModel.aggregate([
        {
          $match: {
            email: email,
          },
        },
        {
          $addFields: {
            userTypeObjectId: {
              $cond: [
                { $eq: [{ $type: "$userType" }, "string"] },
                { $toObjectId: "$userType" },
                "$userType",
              ],
            },
          },
        },
        {
          $lookup: {
            from: "roles",
            localField: "userTypeObjectId",
            foreignField: "_id",
            as: "roleInfo",
          },
        },
        {
          $unwind: {
            path: "$roleInfo",
            preserveNullAndEmptyArrays: true, // set to true if role may not exist
          },
        },
        {
          $project: {
            _id: 0,
            userId: "$_id",
            username: "$fullName",
            email: "$email",
            roleId: "$roleInfo.role_id",
            userType: "$roleInfo.name",
            userTypeId: "$userTypeObjectId",
            active: "$roleInfo.isActive",
          },
        },
      ]);

      // console.log("User lookup result:", result);
      return result;
    } catch (err) {
      console.error("Aggregation Error:", err);
      throw err;
    }
  };

  static getLoginUserById = async (Token) => {
    try {
      const logout = await LoginUserModel.findOne({ Token: Token });
      // console.log("Logout data:", logout);
      if (!logout) {
        throw new Error("User not found");
      }
      // const userId = logout.userId;    can be used if needed for further operations
      const updateUser = await LoginUserModel.updateOne(
        { Token: Token },
        { $set: { logoutTime: Date.now() } },
        { new: true }
      );
      return updateUser;
    } catch (error) {
      console.error("Error in getLoginUserById:", error);
      throw error;
    }
  };

  static getDumpReport = async (formattedFromDate, formattedToDate) => {
    if (!formattedFromDate || !formattedToDate) {
      throw new Error("Invalid date range provided");
    }
    const fromDate = new Date(formattedFromDate);
    const toDate = new Date(formattedToDate);
    toDate.setHours(23, 59, 59, 999); // Set to end of the day
    try {
      const results = await TaskModal.aggregate([
        {
          $match: {
            isDeleted: false,
            createdDate: {
              $gte:  fromDate,
              $lte: toDate,
            },
          },
        },
        {
          $addFields: {
            statusObjId: {
              $convert: {
                input: "$Taskstatus",
                to: "objectId",
                onError: null,
                onNull: null,
              },
            },
            assigneeObjId: {
              $convert: {
                input: "$assignto",
                to: "objectId",
                onError: null,
                onNull: null,
              },
            },
          },
        },
        {
          $lookup: {
            from: "taskstatuses",
            localField: "statusObjId",
            foreignField: "_id",
            as: "statusInfo",
          },
        },
        {
          $unwind: {
            path: "$statusInfo",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $lookup: {
            from: "users",
            localField: "assigneeObjId",
            foreignField: "_id",
            as: "userInfo",
          },
        },
        {
          $unwind: {
            path: "$userInfo",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $addFields: {
            departmentObjId: {
              $convert: {
                input: "$userInfo.department", // department is a string
                to: "objectId",
                onError: null,
                onNull: null,
              },
            },
          },
        },
        {
          $lookup: {
            from: "teams", // <- your Team collection
            localField: "departmentObjId",
            foreignField: "_id",
            as: "teamInfo",
          },
        },
        {
          $unwind: {
            path: "$teamInfo",
            preserveNullAndEmptyArrays: true,
          },
        },
        {
          $project: {
            _id: 0,
            taskId: "$taskid",
            taskName: "$name",
            date: {
              $dateToString: {
                format: "%Y-%m-%d",
                date: "$createdDate",
              },
            },
            status: "$statusInfo.name",
            priority: "$priority",
            team: {
              $ifNull: ["$teamInfo.name", "$userInfo.department"],
            },
          },
        },
      ]);
      return results;
    } catch (error) {
      console.error("Error in getDumpReport:", error);
      throw error;
    }
  };
  //
}

module.exports = UserRepositoryMongo;
