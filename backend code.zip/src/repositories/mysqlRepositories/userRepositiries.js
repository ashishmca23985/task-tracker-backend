const conn = require('../../config/db');

class UserRepository {
  // create new user after registartion
  static  createUser=async(userData)=> {
    const query = 'INSERT INTO users (id,FirstName,LastName,Email,PasswordHash,UserName,UserType) VALUES (?, ?, ?, ?,?, ?, ?)';
    try{
    const values = [userData.id, userData.firstName, userData.lastName, userData.email,userData.password,userData.userName,userData.userType];
    console.log(query, values);
    return conn.query(query, values);
    }
    catch(err)
    {
      return err;
    }
  }

  // get user by email
  static  findUserByEmail=async(email)=> {
    const query = `SELECT * FROM users WHERE Email = ?`;
    try{
      const [rows] = await conn.query(query, [email]);
      return rows;
    }
    catch(err){
    return err;
    }
  }

  // Login audit save after login
  static  SaveLoginAudit=async(LoginData)=> {                     
    const query = `INSERT INTO loginaudits (id,UserName,LoginTime,RemoteIP,Status,Latitude,Longitude) VALUES (?,?,?,?,?,?,?)`;
    const params=[LoginData.id,LoginData.UserName,LoginData.LoginTime,LoginData.RemoteIP,LoginData.Status,LoginData.Latitude,LoginData.Longitude];
    try{
      const [rows] = await conn.query(query, params);
      return rows;
    }
    catch(err){
    return err;
    }
  }

  static  SaveUserLoginStatus=async(LoginData)=> {                     
    const query = `INSERT INTO userlogins (UserId,LogInTime,RemoteIp,IsUserActive,UserName,Token) VALUES (?,?,?,?,?,?)`;
    const params=[LoginData.UserId,LoginData.LoginTime,LoginData.RemoteIP,LoginData.Status,LoginData.UserName,LoginData.Token];
    try{
      const [rows] = await conn.query(query, params);
     console.log(query, params);
      return rows;
    }
    catch(err){
    return err;
    }
  }

  //user logut update
  static  SaveUserLoginStatus=async(LoginData)=> {                     
    const query = `INSERT INTO userlogins (UserId,LogInTime,RemoteIp,IsUserActive,UserName,Token) VALUES (?,?,?,?,?,?)`;
    const params=[LoginData.UserId,LoginData.LoginTime,LoginData.RemoteIP,LoginData.Status,LoginData.UserName,LoginData.Token];
    try{
      const [rows] = await conn.query(query, params);
     console.log(query, params);
      return rows;
    }
    catch(err){
    return err;
    }
  }
}

module.exports = UserRepository;
