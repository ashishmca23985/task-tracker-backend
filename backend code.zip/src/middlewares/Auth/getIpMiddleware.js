var geoip = require('geoip-lite');

const getRemoteIp = (req, res, next) => {

  const ipdata =
  req.headers['x-forwarded-for']?.split(',')[0]?.trim() ||
  req.socket?.remoteAddress ||
  req.connection?.remoteAddress;

  console.log("x-forwarded-for:", req.headers['x-forwarded-for']);
  console.log("socket.remoteAddress:", req.socket?.remoteAddress);
  console.log("connection.remoteAddress:", req.connection?.remoteAddress);
  var ip = "180.151.0.18";
  var geo = geoip.lookup(ip);
  // console.log(geo);
  req.clientIp = geo;
  next();
}

module.exports=getRemoteIp;