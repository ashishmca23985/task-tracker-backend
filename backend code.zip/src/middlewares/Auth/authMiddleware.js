const verifyUser=(req,res,next)=>{
    const token=req.header.token;
    next();

}
module.exports={verifyUser};