const mysql=require('mysql2/promise');
const dotenv=require('dotenv');
dotenv.config();

var dbconfig = {
    host     : process.env.HOST || 'localhost',
    user     : process.env.USER || 'root',
    password : process.env.PASSWORD || '',
    database : process.env.DATABASE || 'vpsc_database'
  };

  const conn=mysql.createPool(dbconfig);


  module.exports=conn;
