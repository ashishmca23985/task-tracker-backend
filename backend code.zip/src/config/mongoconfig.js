const mongoose = require('mongoose');
const dotenv=require('dotenv');
dotenv.config();
const MongoUri=process.env.MongoUri || 'mongodb+srv://sharwanrai66:6GVaH3fxrs3Kb2e0@cluster0.bsnvn6j.mongodb.net/taskberry-squad-main?retryWrites=true&w=majority&appName=Cluster0'
const connectDB = async () => {
  try {
    await mongoose.connect(MongoUri);
  
    console.log("data base connected");
  } catch (err) {
    console.error('MongoDB connection error:', err);
    process.exit(1);
  }
};

module.exports = connectDB;
