const { default: mongoose } = require('mongoose');

const LoginAuditSchema=new mongoose.Schema({
    userName:{type:String,required:true},
    loginTime:{type: Date, default: Date.now},
    remoteIp:{type:String,required:false},
    status:{type:Boolean,required:false},
    provider:{type:String,required:false},
    Latittude:{type:String,required:false},
    Longitude:{type:String,required:false},
});


const LoginUserSchema=new mongoose.Schema({
    userName:{type:String,required:true},
    userId:{type:mongoose.Schema.Types.ObjectId,ref:'User', default:null},
    loginTime:{type: Date, default: Date.now},
    logoutTime:{type: Date, default: null},
    remoteIp:{type:String,required:false},
    isActive:{type:Boolean,default:true},
    Token:{type:String,required:true},
});

const LoginAutditModel=new mongoose.model('Loginaudit',LoginAuditSchema);
const LoginUserModel=new mongoose.model('Loginuser',LoginUserSchema);
module.exports={LoginAutditModel,LoginUserModel};