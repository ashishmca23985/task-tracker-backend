const { default: mongoose } = require("mongoose");

const UserSchema = new mongoose.Schema({
  fullName: { type: String, default: null },
  email: { type: String, required: true },
  mobile: { type: String, default: null },
  department: { type: String, default: null }, // refered to team model
  designation: { type: String, default: null },
  reportingto: { type: String, default: null },
  password: { type: String, default: null },
  isActive: { type: Boolean, default: true },
  addedDate: { type: Date, default: Date.now },
  addedby: { type: String, default: null },

  isDeleted: { type: Boolean, default: false },
  deletedDate: { type: Date, default: null },
  deletedby: { type: String, default: null },
  updatedDate: { type: Date, default: null },
  updatedby: { type: String, default: null },
  userType: { type: String, ref: "Roles", default: "683d65cd0ee64dbebeb7a65c" },
  relatedUser: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    default: null,
  },
  assignedTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    default: null,
  },
  departmentmain: { type: String, ref: "Department", default: null },
});

const RoleSchema = new mongoose.Schema({
  name: { type: String, required: true },
  isSuperAdmin: { type: Boolean, default: false },
  isActive: { type: Boolean, default: true },
  deletedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    default: null,
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    default: null,
  },
  modifiedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    default: null,
  },
  modifieddDate: { type: Date, default: null },
  deletedDate: { type: Date, default: null },
  addedDate: { type: Date, default: Date.now },
});

const UserRoleSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  roleId: { type: mongoose.Schema.Types.ObjectId, ref: "Role" },
});

const DepartmentSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true,
    },

    isDeleted: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true }
);

const UserModel = new mongoose.model("User", UserSchema);
const RoleModel = new mongoose.model("Role", RoleSchema);
const UserRoleModel = new mongoose.model("Userrole", UserRoleSchema);
const DepartmentModel = new mongoose.model("Department", DepartmentSchema);

module.exports = { UserModel, RoleModel, UserRoleModel, DepartmentModel };
