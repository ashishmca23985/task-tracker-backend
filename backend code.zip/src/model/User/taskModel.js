const { time } = require("console");
const mongoose = require("mongoose");
const { type } = require("os");

const TaskStatusSchema = new mongoose.Schema({
  name: { type: String },
});

const TaskSchema = new mongoose.Schema({
  taskid: { type: String, required: true },
  name: { type: String, required: true },
  Taskstatus: {
    type: String,
    ref: "Taskstatus",
    default: "684bc70c3c9d30e5d63e35c1", // Default status ID Not Started
  },
  details: { type: String, default: null },
  targetdate: { type: Date, default: null },
  assignto: {
    type: String,
    ref: "User",
    default: null,
  },
  createdby: {
    type: String,
    ref: "User",
    default: null,
  },
  isActive: { type: Boolean, default: true },
  isDeleted: { type: Boolean, default: false },
  deletedBy: { type: String, default: null },
  deletedDate: { type: Date, default: null },
  isOpenFirstTime: { type: Boolean, default: false },
  isOpenFirstTimeDate: { type: Date, default: null },
  createdDate: { type: Date, default: Date.now },
  updatedDate: { type: Date, default: null },
  updatedBy: { type: String, default: null },
  remarks: { type: String, default: null },
  priority:{type: String, default: "Medium", enum: ["Low", "Medium", "High"]},
});

const TaskNotesSchema = new mongoose.Schema({
  taskid: { type: String,ref:'Tasks' },
  notesId:{ type: String},
  notes: { type: String,trim:true },
  addedBy: {type: String,ref: "User"},
  addedDate: { type: Date, default: Date.now },
  updatedDate:{ type: Date, default: null },
  active: { type: Boolean, default: true },
});

const TaskAttachment = new mongoose.Schema({
 taskid: {type:mongoose.Schema.Types.ObjectId, ref: 'Tasks'},
 filename: { type: String, required: true },
  filetype: { type: String, required: true },
  fileurl: { type: String, required: true },
  uploadedBy: { type: String, ref: "User" },
  uploadedDate: { type: Date, default: Date.now },
  isActive: { type: Boolean, default: true },
  isDeleted: { type: Boolean, default: false },
  deletedBy: { type: String, default: null },
  deletedDate: { type: Date, default: null },
  remarks: { type: String, default: null },
},{timestamps: true});



const TaskLogs = new mongoose.Schema({
  taskid: { type: String, required: true },
  description:{
    type: String,
    required: true,
  },
  performedBy: {
    type: String,
    ref: "User",
  },
  performedDate: { type: Date, default: Date.now },
  actions : {
    type: String,
    enum: ["Created", "Updated", "Deleted", "Status Changed", "Document related"],
    default : "Updated",
    required: true,
  },

},{
  timestamps: true,
});

const NotificationSchema = new mongoose.Schema({
  recieverId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  senderId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  taskId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Tasks",
    required: true,
  },
  message: {
    type: String,
    required: true,
  },
  isRead: {
    type: Boolean,
    default: false,
  },
  readDate: {
    type: Date,
    default: null,
  },

},{
  timestamps: true,
})

const TaskModal = new mongoose.model("Tasks", TaskSchema);
const TaskStatusModal = new mongoose.model("Taskstatus", TaskStatusSchema);
const TaskNotesModal = new mongoose.model("Tasknote", TaskNotesSchema);
const TaskLogsModal = new mongoose.model("Tasklogs", TaskLogs);
const TaskAttachmentModal = new mongoose.model("Taskattachment", TaskAttachment);
const NotificationModal = new mongoose.model("Notification", NotificationSchema);
module.exports = { TaskModal, TaskStatusModal,TaskNotesModal ,TaskLogsModal , TaskAttachmentModal , NotificationModal};
