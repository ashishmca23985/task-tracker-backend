const { default: mongoose } = require('mongoose');

const TeamSchema=new mongoose.Schema({
  name:{type:String,required:true},
  isActive:{type:Boolean,default:true},
  isDeleted:{type:Boolean,default:false},
  deletedBy:{type:String,ref:'User',default:null},
  createdBy:{type:String,ref:'User',default:null},

  modifieddDate:{type: Date, default: null },
  deletedDate:{type: Date, default: null },
  addedDate: {type: Date,default:Date.now }
});


const TeamMemberSchema=new mongoose.Schema({
  departmentid:{type:String,ref:'Team',required:true},
  userid:{type:String,ref:'User',required:true},

  addedby:{type:String,ref:'User',default:null},
  addedDate: {type: Date,default:Date.now },

  isdeleted:{type:Boolean,default:false},
  deletedby:{type:String,ref:'User',default:null},
  deletedDate:{type: Date, default: null },

  modifieddDate:{type: Date, default: null },
  isActive:{type:Boolean,default:true}
});


const DesignationSchema=new mongoose.Schema({
  name:{type:String,required:true},
  isActive:{type:Boolean,default:true},
  deletedBy:{type:mongoose.Schema.Types.ObjectId,ref:'User',default:null},
  createdBy:{type:mongoose.Schema.Types.ObjectId,ref:'User',default:null},
  modifiedBy:{type:mongoose.Schema.Types.ObjectId,ref:'User', default:null},
  modifieddDate:{type: Date, default: null },
  deletedDate:{type: Date, default: null },
  addedDate: {type: Date,default:Date.now }
});

const TeamModel=new mongoose.model('Team',TeamSchema);
const TeamMemberModel=new mongoose.model('Teammember',TeamMemberSchema);
const DesignationModel=new mongoose.model('Designation',DesignationSchema);
module.exports={TeamModel,TeamMemberModel,DesignationModel};