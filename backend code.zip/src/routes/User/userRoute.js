const {verifyUser}=require("../../middlewares/Auth/authMiddleware");
const UserController = require('../../controllers/User/userController');
const express=require('express');
const uploadMiddleware = require("../../middlewares/Auth/uploadMiddleware");
const UserRoute=express.Router();

UserRoute.get('/',UserController.getUser);
UserRoute.post('/',UserController.AddUser);
UserRoute.delete('/', UserController.DeleteUser);
UserRoute.put('/', UserController.UpdateUser);
UserRoute.put('/change-password', UserController.ChangePassword);
UserRoute.put('/forgot-password', UserController.ForgotPassword);
UserRoute.post("/assignto", UserController. AssigntoUserupdate); //assing user to user

UserRoute.get("/userProfile", UserController.getProfile); //get user profile
UserRoute.post("/updateProfile", UserController.UpdateProfile); //update user profile

UserRoute.get("/userlistcustom", UserController.getUserListCustom); //get user list custom for assign to


UserRoute.get('/userlist', UserController.getUserDropdown);
UserRoute.get("/all",UserController.getUserforTeamAssign);
UserRoute.post('/task',UserController.addTask);
UserRoute.get('/task',UserController.getTask);
UserRoute.get('/task/details',UserController.getTaskByTaskId);
UserRoute.get('/task/notes/currentnotes',UserController.getCurrentNotes);   //fetch last added notes of a task

UserRoute.get('/task/mytask',UserController.getMyTask); // get my task
UserRoute.get('/task/teamtask',UserController.getTeamTask);

UserRoute.delete('/task',UserController.DeleteTask);
UserRoute.put('/task',UserController.EditTask);
UserRoute.put('/task/reassign',UserController.ReAssignTask);
UserRoute.put('/task/statuschange',UserController.changeTaskStatus);

UserRoute.post('/taskstatus',UserController.addTaskStatus);
UserRoute.get('/taskstatus',UserController.getTaskStatus);
UserRoute.get('/taskstatuswise',UserController.TaskStatusWise);
UserRoute.get('/taskcountstatuswise',UserController.TaskStatusWiseCount);
UserRoute.get('/task-logs', UserController.getTaskLogs); // get task logs

UserRoute.post('/notes',UserController.addNotes); // add notes to task
UserRoute.get('/notes',UserController.getNotes); // get notes of task

UserRoute.get('/task/firsttimeopen',UserController.FirstTimeOpenUpdate); // update first time open of task
UserRoute.get('/task/report',UserController.getReportTaskWise);


UserRoute.get("/user-task-report", UserController.getUserTaskReport); //get user task report

UserRoute.get("/recent-task", UserController.getRecentTask); //get recent task

UserRoute.get("/task-status-chart", UserController.getTaskStatusChart); //get task status chart

UserRoute.patch("/status", UserController.updateUserStatus); //update user status

UserRoute.post("/Dump-Report", UserController.DumpReport); //Dump Report


// files section

UserRoute.post("/upload", uploadMiddleware,UserController.uploadFile); //upload file
UserRoute.get("/attachments", UserController.getFileById); //get file by

UserRoute.get("/files/view", UserController.viewFile); //view file by id
UserRoute.get("/files/download", UserController.downloadFile); //download file by id
UserRoute.delete("/files/delete", UserController.deleteFile); //delete file by id


UserRoute.post("/create-department", UserController.createDepartment); //create department
UserRoute.get("/get-department", UserController.getDepartment); //get department


// analytics section

UserRoute.get('/status-summary', UserController.getStatusSummary)
UserRoute.get('/task-trend', UserController.getTaskTrend)
UserRoute.get('/team-tasks', UserController.getTeamTasks)


// Notification section

UserRoute.get('/notifications', UserController.getNotifications); // get notifications
UserRoute.post('/notifications/mark-as-read', UserController.markNotificationAsRead); // mark
UserRoute.post('/notifications/mark-all-as-read', UserController.markAllNotificationsAsRead); // mark all notifications as read


module.exports=UserRoute;