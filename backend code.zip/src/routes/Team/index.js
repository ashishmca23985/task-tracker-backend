const express=require('express');
const TeamController = require("../../controllers/Team/teamController");
const TeamRoute=express.Router();

TeamRoute.post('/',TeamController.CreateTeam);
TeamRoute.get('/',TeamController.getTeam);
TeamRoute.get('/teamuser',TeamController.getTeamWiseMember);
TeamRoute.delete('/',TeamController.deleteTeam);

TeamRoute.post('/designation',TeamController.CreateDegignation);
TeamRoute.get('/designation',TeamController.getDegignation);
TeamRoute.post('/member',TeamController.AddTeamMember);

TeamRoute.get('/member',TeamController.GetTeamMember);
TeamRoute.get('/teamusers',TeamController.GetTeamByDepartmentId);
TeamRoute.post("/removeuserfromteam", TeamController.removeUserFromTeam); // remove team member



module.exports=TeamRoute;