const express=require('express');
const UserRoute = require('./User/userRoute');
const AuthRoutes = require('./Auth/authRoute');
const TeamRoute = require('./Team');
const Routes=express.Router();

Routes.use('/user',UserRoute);
Routes.use('/auth',AuthRoutes);
Routes.use('/team',TeamRoute);

module.exports=Routes;

