const express=require('express');
const AuthController = require('../../controllers/Auth/authController');
const getRemoteIp =require("../../middlewares/Auth/getIpMiddleware");
const { verifyUser } = require('../../middlewares/Auth/authMiddleware');
const AuthRoutes=express.Router();

AuthRoutes.post('/register',AuthController.UserRegistration);
AuthRoutes.post('/login',getRemoteIp,AuthController.Userlogin);
AuthRoutes.post('/logout',verifyUser,getRemoteIp,AuthController.Logout);
AuthRoutes.post('/role',verifyUser,getRemoteIp,AuthController.AddRole);
AuthRoutes.post('/change-role',verifyUser,getRemoteIp,AuthController.ChangeRole);
module.exports=AuthRoutes;