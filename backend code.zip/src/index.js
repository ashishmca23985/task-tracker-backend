const express = require('express');
const dotenv = require('dotenv');
const connectDB = require('./config/mongoconfig');
const Routes = require('./routes');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

dotenv.config();

const app = express();
const port = process.env.PORT || 3002;

app.use(cors({
  origin: '*',  
}));

app.get('/', (req, res) => {
  res.send("hiiii");
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));


app.use('/api/v1/', Routes);

(async () => {
  try {
    await connectDB();
    app.listen(port, () => {
      console.log(`Server started on port ${port}`);
    });
  } catch (error) {
    console.error("Failed to start server:", error);
    process.exit(1);
  }
})();

module.exports = app; 
